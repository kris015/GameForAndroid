/* Creator &copy Kristijan C. - Ultimate Edition */

// --- DATA & STORAGE ---
const defaultData = {
    coins: 0,
    bestScore: 0,
    inventory: ['hero_default', 'stick_default', 'plat_default', 'bg_default'],
    equipped: { hero: 'hero_default', stick: 'stick_default', platform: 'plat_default', bg: 'bg_default' }
};
let gameData = JSON.parse(localStorage.getItem('stickHeroUltimate')) || defaultData;

function saveData() {
    localStorage.setItem('stickHeroUltimate', JSON.stringify(gameData));
    updateUI();
}

// --- SHOP DATABASE (MEGA PROŠIREN) ---
const shopItems = {
    hero: [
        { id: 'hero_default', name: 'Ninja', color: '#333', band: '#ff4757', price: 0 },
        { id: 'hero_blue', name: 'Sub-Zero', color: '#192a56', band: '#00d2d3', price: 50 },
        { id: 'hero_red', name: 'Daredevil', color: '#c23616', band: '#2f3640', price: 80 },
        { id: 'hero_shadow', name: 'Shadow', color: 'black', band: '#57606f', price: 120 },
        { id: 'hero_gold', name: 'Golden', color: '#FFD700', band: 'white', price: 300 },
        { id: 'hero_hulk', name: 'Toxic', color: '#44bd32', band: '#8c7ae6', price: 150 },
        { id: 'hero_pink', name: 'Sakura', color: '#ff9ff3', band: 'white', price: 100 },
        { id: 'hero_agent', name: 'Agent', color: '#2f3542', band: 'black', price: 200 }
    ],
    stick: [
        { id: 'stick_default', name: 'Wood', color: '#5D4037', width: 4, price: 0 },
        { id: 'stick_red', name: 'Laser Red', color: '#ff4757', width: 3, price: 50 },
        { id: 'stick_blue', name: 'Laser Blue', color: '#1e90ff', width: 3, price: 50 },
        { id: 'stick_gold', name: 'Midas Touch', color: '#FFD700', width: 5, price: 200 },
        { id: 'stick_neon', name: 'Neon Green', color: '#76FF03', width: 3, price: 100 },
        { id: 'stick_dark', name: 'Void', color: 'black', width: 6, price: 150 }
    ],
    platform: [
        { id: 'plat_default', name: 'Stone', color: '#424242', price: 0 },
        { id: 'plat_ice', name: 'Ice Block', color: '#81D4FA', price: 70 },
        { id: 'plat_mars', name: 'Mars', color: '#BF360C', price: 80 },
        { id: 'plat_grass', name: 'Grass', color: '#388E3C', price: 60 },
        { id: 'plat_gold', name: 'Treasure', color: '#FFC107', price: 250 },
        { id: 'plat_cyber', name: 'Cyber', color: '#2c3e50', price: 120 }
    ],
    bg: [
        { id: 'bg_default', name: 'Daylight', colors: ['#a8e6cf', '#dcedc1'], hills: '#81c784', price: 0 },
        { id: 'bg_sunset', name: 'Sunset', colors: ['#ff9966', '#ff5e62'], hills: '#a1484b', price: 100 },
        { id: 'bg_midnight', name: 'Midnight', colors: ['#141E30', '#243B55'], hills: '#1c2a38', price: 150 },
        { id: 'bg_forest', name: 'Deep Forest', colors: ['#134E5E', '#71B280'], hills: '#0e3d4a', price: 120 },
        { id: 'bg_candy', name: 'Candy', colors: ['#ff9a9e', '#fecfef'], hills: '#ff6b81', price: 200 },
        { id: 'bg_void', name: 'The Void', colors: ['#000000', '#434343'], hills: '#222', price: 300 }
    ]
};

// --- GAME VARIABLES ---
Array.prototype.last = function () { return this[this.length - 1]; };
Math.sinus = function (degree) { return Math.sin((degree / 180) * Math.PI); };

let phase = "waiting", lastTimestamp, heroX, heroY, sceneOffset, score = 0;
let platforms = [], sticks = [], coins = [];
let isGameRunning = false;
let currentShopTab = 'hero';

const canvas = document.getElementById("game");
// Set canvas size
function resize() {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    draw();
}
window.addEventListener("resize", resize);

const ctx = canvas.getContext("2d");

// Config
const canvasWidth = 375; // Logic width
const platformHeight = 250;
const heroDistanceFromEdge = 10;
const paddingX = 100;
const perfectAreaSize = 10;
const bgSpeed = 0.2;
// Animation params
const stretchingSpeed = 4;
const turningSpeed = 4;
const walkingSpeed = 4;
const transitioningSpeed = 2;
const fallingSpeed = 2;
const heroWidth = 20; 
const heroHeight = 35; // Visina coveculjka

// UI Refs
const introEl = document.getElementById("introduction");
const perfectEl = document.getElementById("perfect");
const doubleCoinEl = document.getElementById("double-coin-msg");
const scoreEl = document.getElementById("score");
const mainMenu = document.getElementById("main-menu");
const shopScreen = document.getElementById("shop-screen");
const gameOverMenu = document.getElementById("game-over-menu");

// --- INITIALIZATION ---
updateUI();
resize(); 

// Event Listeners
document.getElementById('btn-start').onclick = startGame;
document.getElementById('btn-shop').onclick = openShop;
document.getElementById('btn-restart-go').onclick = () => { gameOverMenu.style.display = 'none'; startGame(); };
document.getElementById('btn-shop-go').onclick = () => { gameOverMenu.style.display = 'none'; openShop(); };
document.getElementById('btn-back').onclick = closeShop;

function updateUI() {
    document.getElementById('coin-count').innerText = gameData.coins;
    document.getElementById('shop-coin-count').innerText = gameData.coins;
    document.getElementById('best-score').innerText = gameData.bestScore;
    document.getElementById('final-best-display').innerText = gameData.bestScore;
}

// --- SHOP LOGIC ---
function openShop() {
    mainMenu.style.display = 'none';
    shopScreen.style.display = 'flex';
    switchTab(currentShopTab);
}

function closeShop() {
    shopScreen.style.display = 'none';
    if(phase === 'falling' || score > 0) gameOverMenu.style.display = 'block';
    else mainMenu.style.display = 'block';
    draw(); // Redraw game to show equipped changes
}

window.switchTab = (category) => {
    currentShopTab = category;
    document.querySelectorAll('.shop-tabs button').forEach(b => b.classList.remove('tab-active'));
    event.target.classList.add('tab-active');
    renderShopItems(category);
}

function renderShopItems(cat) {
    const container = document.getElementById('shop-items');
    container.innerHTML = '';
    
    shopItems[cat].forEach(item => {
        const owned = gameData.inventory.includes(item.id);
        const equipped = gameData.equipped[cat] === item.id;
        
        const card = document.createElement('div');
        card.className = `shop-item-card ${equipped ? 'equipped' : ''} ${!owned ? 'locked' : ''}`;
        
        // Preview Canvas
        const pCv = document.createElement('canvas');
        pCv.width = 70; pCv.height = 70;
        pCv.className = 'item-preview-canvas';
        drawShopPreview(pCv.getContext('2d'), cat, item);
        
        const info = document.createElement('div');
        info.className = 'item-info';
        info.innerHTML = `
            <span class="item-name">${item.name}</span>
            <span class="item-price">${owned ? (equipped ? 'EQUIPPED' : 'OWNED') : item.price + ' 💎'}</span>
        `;
        
        card.appendChild(pCv);
        card.appendChild(info);
        
        card.onclick = () => {
            if (owned) {
                gameData.equipped[cat] = item.id;
                saveData(); renderShopItems(cat); 
            } else if (gameData.coins >= item.price) {
                gameData.coins -= item.price;
                gameData.inventory.push(item.id);
                gameData.equipped[cat] = item.id;
                saveData(); renderShopItems(cat);
            }
        };
        container.appendChild(card);
    });
}

// --- SHARED DRAWING LOGIC (HERO & PREVIEW) ---

// Ova funkcija crta lepog coveculjka i za igru i za shop
function drawHeroVisual(ctx, x, y, color, bandColor, scale = 1) {
    ctx.save();
    ctx.translate(x, y);
    ctx.scale(scale, scale);

    // Boja tela
    ctx.fillStyle = color;

    // Telo (Zaobljeni pravougaonik)
    const w = 20, h = 30; // Dimenzije tela
    ctx.beginPath();
    ctx.roundRect(-w/2, -h, w, h, 5);
    ctx.fill();

    // Glava (Krug)
    ctx.beginPath();
    ctx.arc(0, -h - 8, 8, 0, Math.PI*2);
    ctx.fill();

    // Noge (Jednostavne)
    ctx.strokeStyle = color;
    ctx.lineWidth = 4;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(-5, 0); ctx.lineTo(-5, 8); // Leva
    ctx.moveTo(5, 0); ctx.lineTo(5, 8);   // Desna
    ctx.stroke();

    // Traka (Headband) - vijori se
    ctx.fillStyle = bandColor;
    ctx.fillRect(-9, -h - 12, 18, 4); // Na glavi
    // Repovi trake
    ctx.beginPath();
    ctx.moveTo(-9, -h - 10);
    ctx.lineTo(-25, -h - 15); // Vijori levo
    ctx.lineTo(-22, -h - 8);
    ctx.lineTo(-9, -h - 8);
    ctx.fill();

    // Oko (Belo sa zenicom)
    ctx.fillStyle = "white";
    ctx.beginPath(); ctx.arc(4, -h - 8, 3, 0, Math.PI*2); ctx.fill();
    ctx.fillStyle = "black";
    ctx.beginPath(); ctx.arc(5, -h - 8, 1, 0, Math.PI*2); ctx.fill();

    ctx.restore();
}

function drawShopPreview(ctx, type, item) {
    ctx.clearRect(0,0,70,70);
    const cx = 35, cy = 55; // Base position

    if (type === 'hero') {
        drawHeroVisual(ctx, cx, cy, item.color, item.band, 1.2);
    } 
    else if (type === 'stick') {
        ctx.strokeStyle = item.color;
        ctx.lineWidth = item.width || 4;
        ctx.lineCap = 'round';
        ctx.beginPath(); ctx.moveTo(cx, 10); ctx.lineTo(cx, 60); ctx.stroke();
        // Mali efekat sjaja
        ctx.strokeStyle = "rgba(255,255,255,0.3)"; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.moveTo(cx-2, 10); ctx.lineTo(cx-2, 60); ctx.stroke();
    } 
    else if (type === 'platform') {
        ctx.fillStyle = item.color;
        ctx.fillRect(15, 20, 40, 50);
        ctx.fillStyle = "rgba(0,0,0,0.2)"; // senka
        ctx.fillRect(15, 20, 5, 50);
        // Red marker
        ctx.fillStyle = "red"; ctx.fillRect(33, 20, 4, 4);
    } 
    else if (type === 'bg') {
        const gr = ctx.createLinearGradient(0,0,0,70);
        gr.addColorStop(0, item.colors[0]); gr.addColorStop(1, item.colors[1]);
        ctx.fillStyle = gr; ctx.fillRect(0,0,70,70);
        ctx.fillStyle = item.hills;
        ctx.beginPath(); ctx.moveTo(0,70); ctx.lineTo(0,50); 
        ctx.quadraticCurveTo(35, 40, 70, 50); ctx.lineTo(70,70); ctx.fill();
    }
}

// --- GAME LOGIC ---

function startGame() {
    mainMenu.style.display = 'none';
    isGameRunning = true;
    score = 0;
    scoreEl.innerText = score;
    resetGame();
}

function resetGame() {
    phase = "waiting"; 
    lastTimestamp = undefined; 
    sceneOffset = 0; 
    introEl.style.opacity = 1;
    
    platforms = [{ x: 50, w: 50 }]; 
    generatePlatform(); generatePlatform(); generatePlatform(); generatePlatform();
    
    sticks = [{ x: platforms[0].x + platforms[0].w, length: 0, rotation: 0 }];
    heroX = platforms[0].x + platforms[0].w - heroDistanceFromEdge; 
    heroY = 0;
    
    draw();
}

function generatePlatform() {
    const last = platforms.last(); 
    let furthestX = last.x + last.w;
    
    const x = furthestX + 40 + Math.floor(Math.random() * 160);
    const w = 30 + Math.floor(Math.random() * 50);
    platforms.push({ x, w });
    
    // Generisanje coina
    if (Math.random() > 0.4) {
        // x2 Coin Logic (10% sanse za x2)
        const isDouble = Math.random() > 0.9;
        const color = isDouble ? '#FFD700' : '#00E5FF';
        const val = isDouble ? 2 : 1;
        
        coins.push({ 
            x: furthestX + (x - furthestX)/2, 
            y: canvas.height - platformHeight - 25, 
            collected: false,
            color: color,
            value: val,
            floatOffset: Math.random() * 10
        });
    }
}

// --- INPUT HANDLING (FIXED FOR MOBILE) ---
window.addEventListener("keydown", (e) => {
    if (e.key == " " && isGameRunning) { 
        e.preventDefault();
        if (phase == "waiting") { lastTimestamp = undefined; phase = "stretching"; window.requestAnimationFrame(animate); }
    }
});
window.addEventListener("keyup", (e) => {
    if (e.key == " " && isGameRunning && phase == "stretching") phase = "turning";
});

// Touch / Mouse Handling sa PREVENT DEFAULT da se spreci vibracija
const startInput = (e) => {
    if(e.target.closest('.menu-btn') || e.target.closest('.shop-item-card')) return; // Allow buttons
    if (!isGameRunning || phase != "waiting") return;
    e.preventDefault(); // STOP CONTEXT MENU
    
    lastTimestamp = undefined; 
    introEl.style.opacity = 0;
    phase = "stretching"; 
    window.requestAnimationFrame(animate);
};

const endInput = (e) => {
    if (!isGameRunning) return;
    if (phase == "stretching") {
        phase = "turning";
    }
};

window.addEventListener("mousedown", startInput);
window.addEventListener("mouseup", endInput);
window.addEventListener("touchstart", startInput, { passive: false });
window.addEventListener("touchend", endInput);


// --- MAIN LOOP ---
function animate(timestamp) {
    if (!lastTimestamp) { lastTimestamp = timestamp; window.requestAnimationFrame(animate); return; }
    let delta = timestamp - lastTimestamp;

    // Animacija coina (lebdenje)
    coins.forEach(c => c.floatOffset += 0.1);

    switch (phase) {
        case "waiting": return;
        case "stretching": 
            sticks.last().length += delta / stretchingSpeed; 
            break;
        case "turning":
            sticks.last().rotation += delta / turningSpeed;
            if (sticks.last().rotation > 90) {
                sticks.last().rotation = 90;
                const [nextPlat, perfect] = checkHit();
                if (nextPlat) {
                    score += perfect ? 2 : 1;
                    scoreEl.innerText = score;
                    if (perfect) { 
                        perfectEl.style.opacity = 1; 
                        setTimeout(() => perfectEl.style.opacity = 0, 800); 
                    }
                    generatePlatform();
                }
                phase = "walking";
            }
            break;
        case "walking":
            heroX += delta / walkingSpeed;
            
            // Skupljanje coina
            coins.forEach(c => { 
                if(!c.collected && Math.abs(heroX - c.x) < 20) { 
                    c.collected = true; 
                    gameData.coins += c.value;
                    if(c.value > 1) {
                        doubleCoinEl.style.opacity = 1;
                        setTimeout(() => doubleCoinEl.style.opacity = 0, 800);
                    }
                    saveData();
                } 
            });

            const [nextPlat] = checkHit();
            const stick = sticks.last();
            const maxHeroX = nextPlat ? nextPlat.x + nextPlat.w - heroDistanceFromEdge : stick.x + stick.length + heroWidth + 10;
            
            if (heroX > maxHeroX) {
                heroX = maxHeroX;
                phase = nextPlat ? "transitioning" : "falling";
            }
            break;
        case "transitioning":
            sceneOffset += delta / transitioningSpeed;
            const [next] = checkHit();
            if (sceneOffset > next.x + next.w - paddingX) {
                sticks.push({ x: next.x + next.w, length: 0, rotation: 0 });
                phase = "waiting";
            }
            break;
        case "falling":
            if (sticks.last().rotation < 180) sticks.last().rotation += delta / turningSpeed;
            heroY += delta / fallingSpeed;
            if (heroY > platformHeight + 100) {
                // GAME OVER
                isGameRunning = false;
                if(score > gameData.bestScore) {
                    gameData.bestScore = score;
                    saveData();
                }
                document.getElementById('final-score-display').innerText = score;
                updateUI();
                gameOverMenu.style.display = 'block';
                return;
            }
            break;
    }
    
    draw();
    window.requestAnimationFrame(animate);
    lastTimestamp = timestamp;
}

function checkHit() {
    const s = sticks.last();
    const farX = s.x + s.length;
    const hit = platforms.find(p => p.x < farX && farX < p.x + p.w);
    const perfect = hit && (farX > hit.x + hit.w/2 - perfectAreaSize/2 && farX < hit.x + hit.w/2 + perfectAreaSize/2);
    return [hit, perfect];
}

function getEquippedItem(type) {
    const id = gameData.equipped[type];
    return shopItems[type].find(i => i.id === id) || shopItems[type][0];
}

// --- RENDER ---
function draw() {
    // 1. Clear & Background
    const bgItem = getEquippedItem('bg');
    const gr = ctx.createLinearGradient(0, 0, 0, canvas.height);
    gr.addColorStop(0, bgItem.colors[0]); gr.addColorStop(1, bgItem.colors[1]);
    ctx.fillStyle = gr; 
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Hills Background Decoration
    drawHill(bgItem.hills);

    ctx.save();
    // Center Scene
    ctx.translate((canvas.width - canvasWidth)/2 - sceneOffset, 0);

    // 2. Platforms
    const platItem = getEquippedItem('platform');
    platforms.forEach(({ x, w }) => {
        ctx.fillStyle = platItem.color;
        const y = canvas.height - platformHeight;
        ctx.fillRect(x, y, w, platformHeight);
        
        // 3D effect / Detail on platform
        ctx.fillStyle = "rgba(0,0,0,0.2)";
        ctx.fillRect(x, y, 5, platformHeight); 
        
        // Perfect Center Marker
        if (sticks.last().x < x) {
            ctx.fillStyle = "#ff4757";
            ctx.fillRect(x + w/2 - perfectAreaSize/2, y, perfectAreaSize, 5);
        }
    });

    // 3. Sticks
    const stickItem = getEquippedItem('stick');
    sticks.forEach((s) => {
        ctx.save();
        ctx.translate(s.x, canvas.height - platformHeight);
        ctx.rotate((Math.PI/180) * s.rotation);
        
        ctx.strokeStyle = stickItem.color;
        ctx.lineWidth = stickItem.width || 4;
        ctx.lineCap = "round";
        ctx.beginPath();
        ctx.moveTo(0,0);
        ctx.lineTo(0, -s.length);
        ctx.stroke();
        ctx.restore();
    });

    // 4. Hero (Using the NEW Visual function)
    const heroItem = getEquippedItem('hero');
    // Calculate draw position
    const drawX = heroX; 
    const drawY = heroY + canvas.height - platformHeight;
    drawHeroVisual(ctx, drawX, drawY, heroItem.color, heroItem.band);

    // 5. Coins
    coins.forEach(c => {
        if(c.collected) return;
        const floatY = c.y + Math.sin(c.floatOffset) * 5;
        
        ctx.beginPath();
        ctx.fillStyle = c.color;
        ctx.strokeStyle = "white";
        ctx.lineWidth = 2;
        // Diamond shape
        ctx.moveTo(c.x, floatY - 12);
        ctx.lineTo(c.x + 10, floatY);
        ctx.lineTo(c.x, floatY + 12);
        ctx.lineTo(c.x - 10, floatY);
        ctx.closePath();
        ctx.fill(); ctx.stroke();
        
        // Inner detail
        ctx.fillStyle = "rgba(255,255,255,0.4)";
        ctx.beginPath();
        ctx.moveTo(c.x, floatY - 12);
        ctx.lineTo(c.x + 5, floatY - 5);
        ctx.lineTo(c.x, floatY);
        ctx.fill();
    });

    ctx.restore();
}

function drawHill(color) {
    // Simple decorative hill in background
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.moveTo(0, canvas.height);
    ctx.lineTo(0, canvas.height - 150);
    // Parallax effect logic simplified for performance
    const offset = sceneOffset * 0.2;
    for(let i=0; i<=canvas.width; i+=10) {
        ctx.lineTo(i, canvas.height - 150 + Math.sin((i + offset) * 0.01) * 20);
    }
    ctx.lineTo(canvas.width, canvas.height);
    ctx.fill();
}