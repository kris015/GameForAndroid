/* Creator &copy Kristijan C. - Ultimate Edition */

// --- ZVUČNI SISTEM (DODATO NA POČETKODA) ---
const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
const sounds = {
    coin: () => playNote(600, "sine", 0.1),
    fall: () => playNote(150, "sawtooth", 0.5, 50), // Klizni padajući ton
    revive: () => { playNote(400, "square", 0.1); setTimeout(() => playNote(600, "square", 0.2), 100); }
};

function playNote(freq, type, duration, slideTo = null) {
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, audioCtx.currentTime);
    if (slideTo) osc.frequency.exponentialRampToValueAtTime(slideTo, audioCtx.currentTime + duration);
    gain.gain.setValueAtTime(0.1, audioCtx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + duration);
    osc.connect(gain);
    gain.connect(audioCtx.destination);
    osc.start();
    osc.stop(audioCtx.currentTime + duration);
}

// --- DATA & STORAGE ---
const defaultData = {
    coins: 0,
    bestScore: 0,
    inventory: ['hero_default', 'stick_default', 'plat_default', 'bg_default'],
    equipped: { hero: 'hero_default', stick: 'stick_default', platform: 'plat_default', bg: 'bg_default' }
};
let gameData = JSON.parse(localStorage.getItem('stickHeroUltimate')) || defaultData;

function saveData() {
    localStorage.setItem('stickHeroUltimate', JSON.stringify(gameData));
    updateUI();
}

// --- SHOP DATABASE (MEGA PROŠIREN) ---
const shopItems = {
    hero: [
        { id: 'hero_default', name: 'Ninja', color: '#333', band: '#ff4757', price: 0 },
        { id: 'hero_blue', name: 'Sub-Zero', color: '#192a56', band: '#00d2d3', price: 1 },
        { id: 'hero_red', name: 'Daredevil', color: '#c23616', band: '#2f3640', price: 1 },
        { id: 'hero_shadow', name: 'Shadow', color: 'black', band: '#57606f', price: 1 },
        { id: 'hero_gold', name: 'Golden', color: '#FFD700', band: 'white', price: 1 },
        { id: 'hero_hulk', name: 'Toxic', color: '#44bd32', band: '#8c7ae6', price: 1 },
        { id: 'hero_pink', name: 'Sakura', color: '#ff9ff3', band: 'white', price: 1 },
        { id: 'hero_agent', name: 'Agent', color: '#2f3542', band: 'black', price: 1 },
        { id: 'hero_cyberpunk', name: 'Cyberpunk', color: '#ff00ff', band: '#00ffff', price: 1 },
        { id: 'hero_neon_purple', name: 'Neon Prince', color: '#9d4edd', band: '#ff6d00', price: 1 },
        { id: 'hero_galaxy', name: 'Galaxy', color: '#240046', band: '#5a189a', price: 1 },
        { id: 'hero_lava', name: 'Lava Lord', color: '#ff5400', band: '#ffbd00', price: 1 },
        { id: 'hero_ice_king', name: 'Ice King', color: '#a2d2ff', band: '#cdb4db', price: 1 },
        { id: 'hero_dragon', name: 'Dragon Scale', color: '#ff0054', band: '#ffbd00', price: 1 },
        { id: 'hero_phantom', name: 'Phantom', color: '#560bad', band: '#b5179e', price: 1 },
        { id: 'hero_samurai', name: 'Samurai', color: '#2d00f7', band: '#f20089', price: 1 },
        { id: 'hero_void', name: 'Void Walker', color: '#000000', band: '#3c096c', price: 1 },
        { id: 'hero_sunset', name: 'Sunset Warrior', color: '#ff6d00', band: '#ff9e00', price: 1 },
        { id: 'hero_ocean', name: 'Ocean Master', color: '#0077b6', band: '#00b4d8', price: 1 },
        { id: 'hero_forest', name: 'Forest Spirit', color: '#386641', band: '#6a994e', price: 1 },
        { id: 'hero_royal', name: 'Royal Guard', color: '#3a0ca3', band: '#4361ee', price: 1 },
        { id: 'hero_steel', name: 'Steel Titan', color: '#6c757d', band: '#adb5bd', price: 1 },
        { id: 'hero_cosmic', name: 'Cosmic', color: '#10002b', band: '#e0aaff', price: 1 },
        { id: 'hero_rainbow', name: 'Rainbow', color: '#ff595e', band: '#ffca3a', price: 1 },
        { id: 'hero_cyber', name: 'Cyber', color: 'linear-gradient(90deg, #ff00ff, #00ffff)', band: '#66ff00', price: 1 },
        { id: 'hero_linear', name: 'Linear', color: 'linear-gradient(45deg, #ff0000, #ff9900, #ffff00, #00ff00, #00ffff, #0000ff, #9900ff)', band: '#ffffff', price: 1 }
    ],
   stick: [
        { id: 'stick_default', name: 'Wood', color: '#5D4037', width: 4, price: 0 },
        { id: 'stick_red', name: 'Laser Red', color: '#ff4757', width: 3, price: 50 },
        { id: 'stick_blue', name: 'Laser Blue', color: '#1e90ff', width: 3, price: 50 },
        { id: 'stick_gold', name: 'Midas Touch', color: '#FFD700', width: 5, price: 200 },
        { id: 'stick_neon', name: 'Neon Green', color: '#76FF03', width: 3, price: 100 },
        { id: 'stick_dark', name: 'Void', color: 'black', width: 6, price: 150 },
        { id: 'stick_rainbow', name: 'Rainbow Beam', color: 'linear-gradient(45deg, #ff0000, #ff9900, #ffff00, #00ff00, #00ffff, #0000ff, #9900ff)', width: 4, price: 350 },
        { id: 'stick_plasma', name: 'Plasma', color: 'linear-gradient(180deg, #00ffff, #ff00ff)', width: 3, price: 280 },
        { id: 'stick_cosmic', name: 'Cosmic Ray', color: 'linear-gradient(90deg, #3a0ca3, #7209b7, #f72585)', width: 5, price: 400 },
        { id: 'stick_lava', name: 'Lava Flow', color: 'linear-gradient(0deg, #ff5400, #ffbd00)', width: 6, price: 320 },
        { id: 'stick_ice', name: 'Ice Shard', color: 'linear-gradient(180deg, #a2d2ff, #cdb4db)', width: 3, price: 250 },
        { id: 'stick_lightning', name: 'Lightning', color: 'linear-gradient(45deg, #ffff00, #ffffff)', width: 2, price: 300 },
        { id: 'stick_neon_pink', name: 'Neon Pink', color: '#ff006e', width: 3, price: 180 },
        { id: 'stick_galaxy', name: 'Galaxy Rod', color: 'linear-gradient(90deg, #000000, #3c096c, #9d4edd)', width: 5, price: 380 },
        { id: 'stick_diamond', name: 'Diamond', color: 'linear-gradient(45deg, #ffffff, #b9fbc0)', width: 4, price: 420 },
        { id: 'stick_fire', name: 'Fire Blaze', color: 'linear-gradient(0deg, #ff0000, #ff9500)', width: 7, price: 350 },
        { id: 'stick_ocean', name: 'Ocean Wave', color: 'linear-gradient(90deg, #0077b6, #00b4d8)', width: 4, price: 220 },
        { id: 'stick_forest', name: 'Forest Vine', color: 'linear-gradient(0deg, #386641, #a7c957)', width: 5, price: 200 },
        { id: 'stick_sunset', name: 'Sunset', color: 'linear-gradient(45deg, #ff6d00, #ff9e00, #ffbe0b)', width: 4, price: 240 },
        { id: 'stick_cyber', name: 'Cyber Stick', color: 'linear-gradient(90deg, #ff00ff, #00ffff)', width: 3, price: 320 },
        { id: 'stick_royal', name: 'Royal Scepter', color: 'linear-gradient(180deg, #3a0ca3, #4361ee)', width: 6, price: 300 },
        { id: 'stick_phantom', name: 'Phantom Rod', color: 'linear-gradient(45deg, #560bad, #b5179e)', width: 4, price: 280 },
        { id: 'stick_neon_cyan', name: 'Neon Cyan', color: '#00ffff', width: 3, price: 190 },
        { id: 'stick_universe', name: 'Universe', color: 'linear-gradient(90deg, #000000, #14213d, #fca311)', width: 5, price: 450 }
    ],
    platform: [
        { id: 'plat_default', name: 'Stone', color: '#424242', price: 0 },
        { id: 'plat_ice', name: 'Ice Block', color: '#81D4FA', price: 70 },
        { id: 'plat_mars', name: 'Mars', color: '#BF360C', price: 80 },
        { id: 'plat_grass', name: 'Grass', color: '#388E3C', price: 60 },
        { id: 'plat_gold', name: 'Treasure', color: '#FFC107', price: 250 },
        { id: 'plat_cyber', name: 'Cyber', color: '#2c3e50', price: 120 },
        { id: 'plat_crystal', name: 'Crystal', color: 'linear-gradient(135deg, #a2d2ff, #cdb4db)', price: 350 },
        { id: 'plat_lava', name: 'Lava Platform', color: 'linear-gradient(45deg, #ff5400, #ffbd00)', price: 320 },
        { id: 'plat_neon', name: 'Neon Grid', color: 'linear-gradient(90deg, #ff006e, #8338ec)', price: 280 },
        { id: 'plat_galaxy', name: 'Galaxy Floor', color: 'linear-gradient(180deg, #240046, #5a189a)', price: 400 },
        { id: 'plat_ocean', name: 'Ocean Floor', color: 'linear-gradient(0deg, #0077b6, #00b4d8)', price: 220 },
        { id: 'plat_forest', name: 'Mossy Stone', color: 'linear-gradient(135deg, #386641, #6a994e)', price: 200 },
        { id: 'plat_cloud', name: 'Cloud', color: 'linear-gradient(180deg, #ffffff, #f8f9fa)', price: 180 },
        { id: 'plat_diamond', name: 'Diamond Block', color: 'linear-gradient(45deg, #ffffff, #b9fbc0)', price: 420 },
        { id: 'plat_sunset', name: 'Sunset Platform', color: 'linear-gradient(90deg, #ff6d00, #ff9e00)', price: 240 },
        { id: 'plat_rainbow', name: 'Rainbow Bridge', color: 'linear-gradient(90deg, #ff595e, #ffca3a, #8ac926, #1982c4, #6a4c93)', price: 380 },
        { id: 'plat_void', name: 'Void Platform', color: 'linear-gradient(135deg, #000000, #3c096c)', price: 450 },
        { id: 'plat_cosmic', name: 'Cosmic', color: 'linear-gradient(45deg, #10002b, #e0aaff)', price: 500 },
        { id: 'plat_royal', name: 'Royal Platform', color: 'linear-gradient(180deg, #3a0ca3, #4361ee)', price: 300 },
        { id: 'plat_phantom', name: 'Phantom Platform', color: 'linear-gradient(135deg, #560bad, #b5179e)', price: 280 },
        { id: 'plat_cyberpunk', name: 'Cyberpunk', color: 'linear-gradient(90deg, #ff00ff, #00ffff)', price: 350 },
        { id: 'plat_steel', name: 'Steel Grid', color: 'linear-gradient(135deg, #6c757d, #adb5bd)', price: 180 },
        { id: 'plat_golden_brick', name: 'Golden Brick', color: 'linear-gradient(45deg, #ffd700, #ffed4e)', price: 320 },
        { id: 'plat_neon_blue', name: 'Neon Blue', color: 'linear-gradient(90deg, #4cc9f0, #4361ee)', price: 260 },
        { id: 'plat_universe', name: 'Universe Floor', color: 'linear-gradient(180deg, #000000, #14213d)', price: 480 }
    ],
    bg: [
        { id: 'bg_default', name: 'Daylight', colors: ['#a8e6cf', '#dcedc1'], hills: '#81c784', price: 0 },
        { id: 'bg_sunset', name: 'Sunset', colors: ['#ff9966', '#ff5e62'], hills: '#a1484b', price: 100 },
        { id: 'bg_midnight', name: 'Midnight', colors: ['#141E30', '#243B55'], hills: '#1c2a38', price: 150 },
        { id: 'bg_forest', name: 'Deep Forest', colors: ['#134E5E', '#71B280'], hills: '#0e3d4a', price: 120 },
        { id: 'bg_candy', name: 'Candy', colors: ['#ff9a9e', '#fecfef'], hills: '#ff6b81', price: 200 },
        { id: 'bg_void', name: 'The Void', colors: ['#000000', '#434343'], hills: '#222', price: 300 },
        { id: 'bg_aurora', name: 'Aurora', colors: ['#00b4d8', '#9d4edd'], hills: '#7209b7', price: 350 },
        { id: 'bg_neon_city', name: 'Neon City', colors: ['#ff006e', '#8338ec'], hills: '#3a86ff', price: 320 },
        { id: 'bg_cyberpunk', name: 'Cyberpunk 2077', colors: ['#ff00ff', '#00ffff'], hills: '#ff5400', price: 380 },
        { id: 'bg_galaxy', name: 'Milky Way', colors: ['#240046', '#5a189a'], hills: '#9d4edd', price: 450 },
        { id: 'bg_lava_world', name: 'Lava World', colors: ['#ff5400', '#ffbd00'], hills: '#ff9500', price: 330 },
        { id: 'bg_ocean_deep', name: 'Ocean Deep', colors: ['#0077b6', '#00b4d8'], hills: '#023e8a', price: 280 },
        { id: 'bg_forest_magic', name: 'Magic Forest', colors: ['#386641', '#a7c957'], hills: '#6a994e', price: 260 },
        { id: 'bg_cosmic', name: 'Cosmic Storm', colors: ['#10002b', '#e0aaff'], hills: '#7b2cbf', price: 500 },
        { id: 'bg_rainbow', name: 'Rainbow Paradise', colors: ['#ff595e', '#ffca3a', '#8ac926', '#1982c4', '#6a4c93'], hills: '#ff006e', price: 420 },
        { id: 'bg_ice_kingdom', name: 'Ice Kingdom', colors: ['#a2d2ff', '#cdb4db'], hills: '#bde0fe', price: 310 },
        { id: 'bg_desert', name: 'Desert Dunes', colors: ['#f4a261', '#e76f51'], hills: '#e9c46a', price: 220 },
        { id: 'bg_sunrise', name: 'Sunrise', colors: ['#ff6d00', '#ff9e00'], hills: '#ffbe0b', price: 240 },
        { id: 'bg_royal', name: 'Royal Palace', colors: ['#3a0ca3', '#4361ee'], hills: '#4cc9f0', price: 370 },
        { id: 'bg_phantom', name: 'Phantom Realm', colors: ['#560bad', '#b5179e'], hills: '#7209b7', price: 340 },
        { id: 'bg_matrix', name: 'The Matrix', colors: ['#00ff41', '#008f11'], hills: '#003b00', price: 390 },
        { id: 'bg_starry_night', name: 'Starry Night', colors: ['#000814', '#001d3d'], hills: '#003566', price: 410 },
        { id: 'bg_fire_kingdom', name: 'Fire Kingdom', colors: ['#dc2f02', '#e85d04'], hills: '#f48c06', price: 290 },
        { id: 'bg_cherry_blossom', name: 'Cherry Blossom', colors: ['#ffafcc', '#ffc8dd'], hills: '#cdb4db', price: 270 },
        { id: 'bg_universe', name: 'Universe', colors: ['#000000', '#14213d'], hills: '#fca311', price: 480 }
    ]
};

// --- GAME VARIABLES ---
Array.prototype.last = function () { return this[this.length - 1]; };
Math.sinus = function (degree) { return Math.sin((degree / 180) * Math.PI); };

let phase = "waiting", lastTimestamp, heroX, heroY, sceneOffset, score = 0;
let platforms = [], sticks = [], coins = [];
let isGameRunning = false;
let currentShopTab = 'hero';
let walkCycle = 0; // DODATO: Varijabla za animaciju hodanja

const canvas = document.getElementById("game");
// Set canvas size
function resize() {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    draw();
}
window.addEventListener("resize", resize);

const ctx = canvas.getContext("2d");

// Config
const canvasWidth = 375; // Logic width
const platformHeight = 250;
const heroDistanceFromEdge = 10;
const paddingX = 100;
const perfectAreaSize = 10;
const bgSpeed = 0.2;
// Animation params
const stretchingSpeed = 4;
const turningSpeed = 4;
const walkingSpeed = 4;
const transitioningSpeed = 2;
const fallingSpeed = 2;
const heroWidth = 20; 
const heroHeight = 35; // Visina coveculjka

// UI Refs
const introEl = document.getElementById("introduction");
const perfectEl = document.getElementById("perfect");
const doubleCoinEl = document.getElementById("double-coin-msg");
const scoreEl = document.getElementById("score");
const mainMenu = document.getElementById("main-menu");
const shopScreen = document.getElementById("shop-screen");
const gameOverMenu = document.getElementById("game-over-menu");

// --- REVIVE BUTTON LOGIC (ISPRAVLJENO) ---
document.getElementById('btn-revive').onclick = () => {
    if (gameData.coins >= 20) {
        gameData.coins -= 20;
        saveData();
        sounds.revive();
        
        // Izbriši sve štapove osim poslednjeg koji treba da ostane uspravan
        const lastStick = sticks.last();
        sticks = [];
        
        // Pronađi poslednju platformu na kojoj smo bili
        // Treba da nađemo platformu na kojoj je heroj stajao pre pada
        let revivePlatformIndex = 0;
        for (let i = platforms.length - 1; i >= 0; i--) {
            if (platforms[i].x <= heroX && heroX <= platforms[i].x + platforms[i].w) {
                revivePlatformIndex = i;
                break;
            }
        }
        
        const revivePlatform = platforms[revivePlatformIndex];
        
        // Resetuj sve varijable
        heroX = revivePlatform.x + revivePlatform.w - heroDistanceFromEdge;
        heroY = 0;
        phase = "waiting";
        walkCycle = 0;
        sceneOffset = 0;
        
        // Resetuj štapove - kreiraj novi uspravan štap na platformi za revive
        sticks = [{ 
            x: revivePlatform.x + revivePlatform.w, 
            length: 0, 
            rotation: 0 
        }];
        
        // Resetuj padnuti štap - ako postoji poslednji štap, stavi ga uspravno
        if (lastStick) {
            lastStick.rotation = 0;
            // Postavi ga na poziciju iza poslednje platforme
            lastStick.x = revivePlatform.x + revivePlatform.w;
        }
        
        // Skloni meni i nastavi
        gameOverMenu.style.display = 'none';
        isGameRunning = true;
        lastTimestamp = undefined; // Resetuj vreme za animaciju
        window.requestAnimationFrame(animate);
    }
};

// --- INITIALIZATION ---
updateUI();
resize(); 

// Event Listeners
document.getElementById('btn-start').onclick = startGame;
document.getElementById('btn-shop').onclick = openShop;
document.getElementById('btn-restart-go').onclick = () => { gameOverMenu.style.display = 'none'; startGame(); };
document.getElementById('btn-shop-go').onclick = () => { gameOverMenu.style.display = 'none'; openShop(); };
document.getElementById('btn-back').onclick = closeShop;

function updateUI() {
    document.getElementById('coin-count').innerText = gameData.coins;
    document.getElementById('shop-coin-count').innerText = gameData.coins;
    document.getElementById('best-score').innerText = gameData.bestScore;
    document.getElementById('final-score-display').innerText = score;
    document.getElementById('final-best-display').innerText = gameData.bestScore;
}

// --- SHOP LOGIC ---
function openShop() {
    mainMenu.style.display = 'none';
    shopScreen.style.display = 'flex';
    switchTab(currentShopTab);
}

function closeShop() {
    shopScreen.style.display = 'none';
    if(phase === 'falling' || score > 0) gameOverMenu.style.display = 'block';
    else mainMenu.style.display = 'block';
    draw(); // Redraw game to show equipped changes
}

window.switchTab = (category) => {
    currentShopTab = category;
    document.querySelectorAll('.shop-tabs button').forEach(b => b.classList.remove('tab-active'));
    event.target.classList.add('tab-active');
    renderShopItems(category);
}

function renderShopItems(cat) {
    const container = document.getElementById('shop-items');
    container.innerHTML = '';
    
    shopItems[cat].forEach(item => {
        const owned = gameData.inventory.includes(item.id);
        const equipped = gameData.equipped[cat] === item.id;
        
        const card = document.createElement('div');
        card.className = `shop-item-card ${equipped ? 'equipped' : ''} ${!owned ? 'locked' : ''}`;
        
        // Preview Canvas
        const pCv = document.createElement('canvas');
        pCv.width = 70; pCv.height = 70;
        pCv.className = 'item-preview-canvas';
        drawShopPreview(pCv.getContext('2d'), cat, item);
        
        const info = document.createElement('div');
        info.className = 'item-info';
        info.innerHTML = `
            <span class="item-name">${item.name}</span>
            <span class="item-price">${owned ? (equipped ? 'EQUIPPED' : 'OWNED') : item.price + ' 💎'}</span>
        `;
        
        card.appendChild(pCv);
        card.appendChild(info);
        
        card.onclick = () => {
            if (owned) {
                gameData.equipped[cat] = item.id;
                saveData(); renderShopItems(cat); 
            } else if (gameData.coins >= item.price) {
                gameData.coins -= item.price;
                gameData.inventory.push(item.id);
                gameData.equipped[cat] = item.id;
                saveData(); renderShopItems(cat);
            }
        };
        container.appendChild(card);
    });
}

// --- SHARED DRAWING LOGIC (HERO & PREVIEW) ---

// Ova funkcija crta lepog coveculjka i za igru i za shop sa ANIMACIJOM
function drawHeroVisual(ctx, x, y, color, bandColor, scale = 1, isWalking = false) {
    ctx.save();
    ctx.translate(x, y - 8);
    ctx.scale(scale, scale);

    // DODATO: Animacija nogu
    const legMove = isWalking ? Math.sin(walkCycle) * 6 : 0;
    
    // Noge sa animacijom
    ctx.strokeStyle = applyStyle(ctx, color, -5, 0, 10, 8);
    ctx.lineWidth = 4;
    ctx.lineCap = 'round';
    
    ctx.beginPath();
    ctx.moveTo(-5, 0); ctx.lineTo(-5, 8 + legMove); // Leva noga
    ctx.moveTo(5, 0); ctx.lineTo(5, 8 - legMove);   // Desna noga
    ctx.stroke();

    // Telo
    const w = 20, h = 30;
    ctx.fillStyle = applyStyle(ctx, color, -w/2, -h, w, h);
    ctx.beginPath(); 
    ctx.roundRect(-w/2, -h, w, h, 5); 
    ctx.fill();

    // Glava
    ctx.fillStyle = applyStyle(ctx, color, -8, -h - 16, 16, 16);
    ctx.beginPath(); 
    ctx.arc(0, -h - 8, 8, 0, Math.PI*2); 
    ctx.fill();

    // Traka (Headband)
    ctx.fillStyle = bandColor;
    ctx.fillRect(-9, -h - 12, 18, 4);
    ctx.beginPath();
    ctx.moveTo(-9, -h - 10);
    ctx.lineTo(-25, -h - 15);
    ctx.lineTo(-22, -h - 8);
    ctx.lineTo(-9, -h - 8);
    ctx.fill();

    // Oči
    ctx.fillStyle = "white";
    ctx.beginPath(); ctx.arc(4, -h - 8, 3, 0, Math.PI*2); ctx.fill();
    ctx.fillStyle = "black";
    ctx.beginPath(); ctx.arc(5, -h - 8, 1, 0, Math.PI*2); ctx.fill();

    ctx.restore();
}

function drawShopPreview(ctx, type, item) {
    ctx.clearRect(0, 0, 70, 70);
    const cx = 35, cy = 65; 

    if (type === 'hero') {
        // Heroji koriste hex boje, to radi normalno
        drawHeroVisual(ctx, cx, cy, item.color, item.band, 1.2);
    } 
    else if (type === 'stick') {
        // Provera za gradijent na štapu
        ctx.strokeStyle = applyStyle(ctx, item.color, cx, 10, 0, 50);
        ctx.lineWidth = item.width || 4;
        ctx.lineCap = 'round';
        ctx.beginPath(); 
        ctx.moveTo(cx, 10); 
        ctx.lineTo(cx, 60); 
        ctx.stroke();
    } 
    else if (type === 'platform') {
        // Provera za gradijent na platformi
        ctx.fillStyle = applyStyle(ctx, item.color, 15, 20, 40, 50);
        ctx.fillRect(15, 20, 40, 50);
        ctx.fillStyle = "rgba(0,0,0,0.1)"; 
        ctx.fillRect(15, 20, 5, 50);
    } 
    else if (type === 'bg') {
        const gr = ctx.createLinearGradient(0, 0, 0, 70);
        item.colors.forEach((c, i) => gr.addColorStop(i/(item.colors.length-1), c));
        ctx.fillStyle = gr; 
        ctx.fillRect(0, 0, 70, 70);
        ctx.fillStyle = item.hills;
        ctx.beginPath(); 
        ctx.moveTo(0, 70); ctx.lineTo(0, 50); 
        ctx.quadraticCurveTo(35, 40, 70, 50); ctx.lineTo(70, 70); 
        ctx.fill();
    }
}

// --- GAME LOGIC ---

function startGame() {
    mainMenu.style.display = 'none';
    isGameRunning = true;
    score = 0;
    scoreEl.innerText = score;
    resetGame();
}

function resetGame() {
    phase = "waiting"; 
    lastTimestamp = undefined; 
    sceneOffset = 0; 
    walkCycle = 0; // Resetujemo animaciju hodanja
    introEl.style.opacity = 1;
    
    platforms = [{ x: 50, w: 50 }]; 
    generatePlatform(); generatePlatform(); generatePlatform(); generatePlatform();
    
    sticks = [{ x: platforms[0].x + platforms[0].w, length: 0, rotation: 0 }];
    heroX = platforms[0].x + platforms[0].w - heroDistanceFromEdge; 
    heroY = 0;
    
    coins = []; // Resetuj i coine
    
    draw();
}

function generatePlatform() {
    const last = platforms.last(); 
    let furthestX = last.x + last.w;
    
    const x = furthestX + 40 + Math.floor(Math.random() * 160);
    const w = 30 + Math.floor(Math.random() * 50);
    platforms.push({ x, w });
    
    // Generisanje coina
    if (Math.random() > 0.4) {
        // x2 Coin Logic (10% sanse za x2)
        const isDouble = Math.random() > 0.9;
        const color = isDouble ? '#FFD700' : '#00E5FF';
        const val = isDouble ? 2 : 1;
        
        coins.push({ 
            x: furthestX + (x - furthestX)/2, 
            y: canvas.height - platformHeight - 25, 
            collected: false,
            color: color,
            value: val,
            floatOffset: Math.random() * 10
        });
    }
}

// --- INPUT HANDLING (FIXED FOR MOBILE) ---
window.addEventListener("keydown", (e) => {
    if (e.key == " " && isGameRunning) { 
        e.preventDefault();
        if (phase == "waiting") { lastTimestamp = undefined; phase = "stretching"; window.requestAnimationFrame(animate); }
    }
});
window.addEventListener("keyup", (e) => {
    if (e.key == " " && isGameRunning && phase == "stretching") phase = "turning";
});

// Touch / Mouse Handling sa PREVENT DEFAULT da se spreci vibracija
const startInput = (e) => {
    if(e.target.closest('.menu-btn') || e.target.closest('.shop-item-card')) return; // Allow buttons
    if (!isGameRunning || phase != "waiting") return;
    e.preventDefault(); // STOP CONTEXT MENU
    
    lastTimestamp = undefined; 
    introEl.style.opacity = 0;
    phase = "stretching"; 
    window.requestAnimationFrame(animate);
};

const endInput = (e) => {
    if (!isGameRunning) return;
    if (phase == "stretching") {
        phase = "turning";
    }
};

window.addEventListener("mousedown", startInput);
window.addEventListener("mouseup", endInput);
window.addEventListener("touchstart", startInput, { passive: false });
window.addEventListener("touchend", endInput);


// --- MAIN LOOP ---
function animate(timestamp) {
    if (!lastTimestamp) { lastTimestamp = timestamp; window.requestAnimationFrame(animate); return; }
    let delta = timestamp - lastTimestamp;

    // Animacija coina (lebdenje)
    coins.forEach(c => c.floatOffset += 0.1);

    switch (phase) {
        case "waiting": return;
        case "stretching": 
            sticks.last().length += delta / stretchingSpeed; 
            break;
        case "turning":
            sticks.last().rotation += delta / turningSpeed;
            if (sticks.last().rotation > 90) {
                sticks.last().rotation = 90;
                const [nextPlat, perfect] = checkHit();
                if (nextPlat) {
                    score += perfect ? 2 : 1;
                    scoreEl.innerText = score;
                    if (perfect) { 
                        perfectEl.style.opacity = 1; 
                        setTimeout(() => perfectEl.style.opacity = 0, 800); 
                    }
                    generatePlatform();
                }
                phase = "walking";
            }
            break;
        case "walking":
            heroX += delta / walkingSpeed;
            walkCycle += delta * 0.15; // DODATO: Brzina mrdanja nogu
            
            // Skupljanje coina
            coins.forEach(c => { 
                if(!c.collected && Math.abs(heroX - c.x) < 20) { 
                    c.collected = true; 
                    gameData.coins += c.value;
                    sounds.coin(); // DODATO: Zvuk pri skupljanju novčića
                    if(c.value > 1) {
                        doubleCoinEl.style.opacity = 1;
                        setTimeout(() => doubleCoinEl.style.opacity = 0, 800);
                    }
                    saveData();
                } 
            });

            const [nextPlat] = checkHit();
            const stick = sticks.last();
            const maxHeroX = nextPlat ? nextPlat.x + nextPlat.w - heroDistanceFromEdge : stick.x + stick.length + heroWidth + 10;
            
            if (heroX > maxHeroX) {
                heroX = maxHeroX;
                phase = nextPlat ? "transitioning" : "falling";
            }
            break;
        case "transitioning":
            sceneOffset += delta / transitioningSpeed;
            const [next] = checkHit();
            if (sceneOffset > next.x + next.w - paddingX) {
                sticks.push({ x: next.x + next.w, length: 0, rotation: 0 });
                phase = "waiting";
            }
            break;
        case "falling":
            if (sticks.last().rotation < 180) sticks.last().rotation += delta / turningSpeed;
            heroY += delta / fallingSpeed;
            
            // DODATO: Pusti zvuk pada jednom kad počne padati
            if (heroY < 50 && heroY > 0) sounds.fall();
            
            if (heroY > platformHeight + 100) {
                // GAME OVER
                isGameRunning = false;
                if(score > gameData.bestScore) {
                    gameData.bestScore = score;
                    saveData();
                }
                document.getElementById('final-score-display').innerText = score;
                updateUI();
                
                // DODATO: Prikaz dugmeta za revive
                const reviveBtn = document.getElementById('btn-revive');
                reviveBtn.style.display = gameData.coins >= 20 ? 'block' : 'none';
                gameOverMenu.style.display = 'block';
                return;
            }
            break;
    }
    
    draw();
    window.requestAnimationFrame(animate);
    lastTimestamp = timestamp;
}

function checkHit() {
    const s = sticks.last();
    const farX = s.x + s.length;
    const hit = platforms.find(p => p.x < farX && farX < p.x + p.w);
    const perfect = hit && (farX > hit.x + hit.w/2 - perfectAreaSize/2 && farX < hit.x + hit.w/2 + perfectAreaSize/2);
    return [hit, perfect];
}

function getEquippedItem(type) {
    const id = gameData.equipped[type];
    return shopItems[type].find(i => i.id === id) || shopItems[type][0];
}

// --- RENDER ---
function draw() {
    // 1. Clear & Background
    const bgItem = getEquippedItem('bg');
    const gr = ctx.createLinearGradient(0, 0, 0, canvas.height);
    gr.addColorStop(0, bgItem.colors[0]); gr.addColorStop(1, bgItem.colors[1]);
    ctx.fillStyle = gr; 
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Hills Background Decoration
    drawHill(bgItem.hills);

    ctx.save();
    // Center Scene
    ctx.translate((canvas.width - canvasWidth)/2 - sceneOffset, 0);

    // 2. Platforms
    const platItem = getEquippedItem('platform');
    platforms.forEach(({ x, w }) => {
        ctx.fillStyle = applyStyle(ctx, platItem.color, x, canvas.height - platformHeight, w, platformHeight);
        ctx.fillRect(x, canvas.height - platformHeight, w, platformHeight);
        const y = canvas.height - platformHeight;
        ctx.fillRect(x, y, w, platformHeight);
        
        // 3D effect / Detail on platform
        ctx.fillStyle = "rgba(0,0,0,0.2)";
        ctx.fillRect(x, y, 5, platformHeight); 
        
        // Perfect Center Marker
        // Perfect Center Marker kao krug
if (sticks.last().x < x) {
    ctx.fillStyle = "#ff4757";
    const cx = x + w/2;      // X centar platforme
    const cy = y + 2.5;      // Y centar marker-a (sredina visine pravougaonika)
    const radius = perfectAreaSize / 2; 
    ctx.beginPath();
    ctx.arc(cx, cy, radius, 0, Math.PI * 2);
    ctx.fill();
}

    });

    // 3. Sticks
    const stickItem = getEquippedItem('stick');
    sticks.forEach((s) => {
        ctx.save();
        ctx.translate(s.x, canvas.height - platformHeight);
        ctx.rotate((Math.PI/180) * s.rotation);
        
        ctx.strokeStyle = applyStyle(ctx, stickItem.color, 0, 0, 0, -s.length);
        ctx.lineWidth = stickItem.width || 4;
        ctx.lineCap = "round";
        ctx.beginPath();
        ctx.moveTo(0,0);
        ctx.lineTo(0, -s.length);
        ctx.stroke();
        ctx.restore();
    });

    // 4. Hero (Using the NEW Visual function sa animacijom)
    const heroItem = getEquippedItem('hero');
    // Calculate draw position
    const drawX = heroX; 
    const drawY = heroY + canvas.height - platformHeight;
    drawHeroVisual(ctx, drawX, drawY, heroItem.color, heroItem.band, 1, phase === "walking");

    // 5. Coins
    coins.forEach(c => {
        if(c.collected) return;
        const floatY = c.y + Math.sin(c.floatOffset) * 5;
        
        ctx.beginPath();
        ctx.fillStyle = c.color;
        ctx.strokeStyle = "white";
        ctx.lineWidth = 2;
        // Diamond shape
        ctx.moveTo(c.x, floatY - 12);
        ctx.lineTo(c.x + 10, floatY);
        ctx.lineTo(c.x, floatY + 12);
        ctx.lineTo(c.x - 10, floatY);
        ctx.closePath();
        ctx.fill(); ctx.stroke();
        
        // Inner detail
        ctx.fillStyle = "rgba(255,255,255,0.4)";
        ctx.beginPath();
        ctx.moveTo(c.x, floatY - 12);
        ctx.lineTo(c.x + 5, floatY - 5);
        ctx.lineTo(c.x, floatY);
        ctx.fill();
    });

    ctx.restore();
}

function drawHill(color) {
    // Simple decorative hill in background
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.moveTo(0, canvas.height);
    ctx.lineTo(0, canvas.height - 150);
    // Parallax effect logic simplified for performance
    const offset = sceneOffset * 0.2;
    for(let i=0; i<=canvas.width; i+=10) {
        ctx.lineTo(i, canvas.height - 150 + Math.sin((i + offset) * 0.01) * 20);
    }
    ctx.lineTo(canvas.width, canvas.height);
    ctx.fill();
}

function applyStyle(ctx, style, x, y, w, h) {
    if (typeof style === 'string' && style.startsWith('linear-gradient')) {
        // Izvlačimo samo HEX kodove ili nazive boja
        const colorMatches = style.match(/#(?:[0-9a-fA-F]{3}){1,2}\b|[a-zA-Z]+/g);
        
        // Filtriramo reči koje nisu boje
        const colors = colorMatches.filter(c => 
            !['linear', 'gradient', 'deg', 'to', 'right', 'bottom', 'left', 'top'].includes(c.toLowerCase())
        );

        const grad = ctx.createLinearGradient(x, y, x + w, y + h);
        colors.forEach((col, index) => {
            grad.addColorStop(index / (colors.length - 1), col);
        });
        return grad;
    }
    return style;
}