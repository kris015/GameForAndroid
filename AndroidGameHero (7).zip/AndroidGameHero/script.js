/* Creator &copy Kristijan C. - Ultimate Edition - Custom creation */

// --- ZVUČNI SISTEM ---
const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
const sounds = {
    coin: () => {
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(800, audioCtx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(1200, audioCtx.currentTime + 0.1);
        gain.gain.setValueAtTime(0.2, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.3);
        osc.connect(gain);
        gain.connect(audioCtx.destination);
        osc.start();
        osc.stop(audioCtx.currentTime + 0.3);
    },
    
    stickFall: () => {
        const osc1 = audioCtx.createOscillator();
        const osc2 = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        
        osc1.type = 'sawtooth';
        osc2.type = 'sawtooth';
        osc1.frequency.setValueAtTime(300, audioCtx.currentTime);
        osc2.frequency.setValueAtTime(180, audioCtx.currentTime);
        osc1.frequency.exponentialRampToValueAtTime(50, audioCtx.currentTime + 0.8);
        osc2.frequency.exponentialRampToValueAtTime(60, audioCtx.currentTime + 0.8);
        
        gain.gain.setValueAtTime(0.4, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.8);
        
        osc1.connect(gain);
        osc2.connect(gain);
        gain.connect(audioCtx.destination);
        
        osc1.start();
        osc2.start();
        osc1.stop(audioCtx.currentTime + 0.8);
        osc2.stop(audioCtx.currentTime + 0.8);
    },
    
    revive: () => {
        const osc1 = audioCtx.createOscillator();
        const osc2 = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        
        osc1.type = 'square';
        osc2.type = 'square';
        osc1.frequency.setValueAtTime(400, audioCtx.currentTime);
        osc2.frequency.setValueAtTime(600, audioCtx.currentTime);
        
        gain.gain.setValueAtTime(0.3, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.3);
        
        osc1.connect(gain);
        osc2.connect(gain);
        gain.connect(audioCtx.destination);
        
        osc1.start();
        osc2.start();
        osc1.stop(audioCtx.currentTime + 0.3);
        osc2.stop(audioCtx.currentTime + 0.3);
    },
    
    perfect: () => {
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.type = 'sine';
        
        osc.frequency.setValueAtTime(600, audioCtx.currentTime);
        osc.frequency.linearRampToValueAtTime(1000, audioCtx.currentTime + 0.2);
        osc.frequency.linearRampToValueAtTime(600, audioCtx.currentTime + 0.4);
        
        gain.gain.setValueAtTime(0.2, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.4);
        
        osc.connect(gain);
        gain.connect(audioCtx.destination);
        osc.start();
        osc.stop(audioCtx.currentTime + 0.4);
    }
};

// --- DATA & STORAGE ---
const defaultData = {
    coins: 0,
    bestScore: 0,
    inventory: [
        'hero_default', 'hat_red', 'cap_none', 'bandana_none', 
        'shoes_default', 'watch_none', 'chain_none',
        'stick_default', 'plat_default', 'bg_default'
    ],
    equipped: { 
        hero: 'hero_default', 
        hat: 'hat_red',
        cap: 'cap_none',
        bandana: 'bandana_none',
        shoes: 'shoes_default', 
        watch: 'watch_none',
        chain: 'chain_none',
        stick: 'stick_default', 
        platform: 'plat_default', 
        bg: 'bg_default' 
    }
};
let gameData = JSON.parse(localStorage.getItem('stickHeroUltimate')) || defaultData;

function saveData() {
    localStorage.setItem('stickHeroUltimate', JSON.stringify(gameData));
    updateUI();
}

// --- SHOP DATABASE ---
const shopItems = {
    hero: [
        { id: 'hero_default', name: 'Ninja', color: '#333', price: 0 },
        { id: 'hero_blue', name: 'Sub-Zero', color: '#192a56', price: 1 },
        { id: 'hero_red', name: 'Daredevil', color: '#c23616', price: 1 },
        { id: 'hero_shadow', name: 'Shadow', color: 'black', price: 1 },
        { id: 'hero_gold', name: 'Golden', color: '#FFD700', price: 1 },
        { id: 'hero_hulk', name: 'Toxic', color: '#44bd32', price: 1 },
        { id: 'hero_pink', name: 'Sakura', color: '#ff9ff3', price: 1 },
        { id: 'hero_agent', name: 'Agent', color: '#2f3542', price: 1 },
        { id: 'hero_cyberpunk', name: 'Cyberpunk', color: '#ff00ff', price: 1 },
        { id: 'hero_neon_purple', name: 'Neon Prince', color: '#9d4edd', price: 1 },
        { id: 'hero_galaxy', name: 'Galaxy', color: '#240046', price: 1 },
        { id: 'hero_lava', name: 'Lava Lord', color: '#ff5400', price: 1 },
        { id: 'hero_ice_king', name: 'Ice King', color: '#a2d2ff', price: 1 },
        { id: 'hero_dragon', name: 'Dragon Scale', color: '#ff0054', price: 1 },
        { id: 'hero_phantom', name: 'Phantom', color: '#560bad', price: 1 },
        { id: 'hero_samurai', name: 'Samurai', color: '#2d00f7', price: 1 },
        { id: 'hero_void', name: 'Void Walker', color: '#000000', price: 1 },
        { id: 'hero_sunset', name: 'Sunset Warrior', color: '#ff6d00', price: 1 },
        { id: 'hero_ocean', name: 'Ocean Master', color: '#0077b6', price: 1 },
        { id: 'hero_forest', name: 'Forest Spirit', color: '#386641', price: 1 },
        { id: 'hero_royal', name: 'Royal Guard', color: '#3a0ca3', price: 1 },
        { id: 'hero_steel', name: 'Steel Titan', color: '#6c757d', price: 1 },
        { id: 'hero_cosmic', name: 'Cosmic', color: '#10002b', price: 1 },
        { id: 'hero_rainbow', name: 'Rainbow', color: '#ff595e', price: 1 },
        { id: 'hero_cyber', name: 'Cyber', color: 'linear-gradient(90deg, #ff00ff, #00ffff)', price: 1 },
        { id: 'hero_linear', name: 'Linear', color: 'linear-gradient(45deg, #ff0000, #ff9900, #ffff00, #00ff00, #00ffff, #0000ff, #9900ff)', price: 1 }
    ],
    
    hats: [
        { id: 'hat_none', name: 'No Hat', type: 'hat', color: 'transparent', price: 0 },
        { id: 'hat_red', name: 'Red Hat', type: 'hat', color: '#ff4757', price: 1 },
        { id: 'hat_blue', name: 'Blue Hat', type: 'hat', color: '#1e90ff', price: 1 },
        { id: 'hat_green', name: 'Green Hat', type: 'hat', color: '#2ecc71', price: 1 },
        { id: 'hat_purple', name: 'Purple Hat', type: 'hat', color: '#9b59b6', price: 1 },
        { id: 'hat_black', name: 'Black Hat', type: 'hat', color: '#2c3e50', price: 1 },
        { id: 'hat_white', name: 'White Hat', type: 'hat', color: '#ffffff', price: 1 },
        { id: 'hat_gold', name: 'Gold Hat', type: 'hat', color: '#FFD700', price: 1 },
        { id: 'hat_cowboy_brown', name: 'Cowboy (Brown)', type: 'hat', color: '#8B4513', price: 1 },
        { id: 'hat_cowboy_black', name: 'Cowboy (Black)', type: 'hat', color: '#000000', price: 1 },
        { id: 'hat_top', name: 'Top Hat', type: 'hat', color: '#2c3e50', price: 1 },
        { id: 'hat_beanie_red', name: 'Beanie (Red)', type: 'hat', color: '#e74c3c', price: 1 },
        { id: 'hat_beanie_blue', name: 'Beanie (Blue)', type: 'hat', color: '#3498db', price: 1 },
        { id: 'hat_party', name: 'Party Hat', type: 'hat', color: 'linear-gradient(45deg, #ff0000, #ff9900, #ffff00, #00ff00, #00ffff, #0000ff, #9900ff)', price: 1 }
    ],
    
    caps: [
        { id: 'cap_none', name: 'No Cap', type: 'cap', color: 'transparent', price: 0 },
        { id: 'cap_default', name: 'Classic Cap', type: 'cap', color: '#333333', price: 1 },
        { id: 'cap_red', name: 'Red Cap', type: 'cap', color: '#ff4757', price: 1 },
        { id: 'cap_blue', name: 'Blue Cap', type: 'cap', color: '#1e90ff', price: 1 },
        { id: 'cap_green', name: 'Green Cap', type: 'cap', color: '#00ce6b', price: 1 },
        { id: 'cap_backwards_red', name: 'Cap Backwards (Red)', type: 'cap', backwards: true, color: '#ff4757', price: 1 },
        { id: 'cap_backwards_blue', name: 'Cap Backwards (Blue)', type: 'cap', backwards: true, color: '#1e90ff', price: 1 },
        { id: 'cap_backwards_black', name: 'Cap Backwards (Black)', type: 'cap', backwards: true, color: '#000000', price: 1 },
        { id: 'cap_snapback_white', name: 'Snapback (White)', type: 'cap', color: '#ffffff', price: 1 },
        { id: 'cap_snapback_black', name: 'Snapback (Black)', type: 'cap', color: '#000000', price: 1 },
        { id: 'cap_trucker', name: 'Trucker Cap', type: 'cap', color: '#2c3e50', price: 1 },
        { id: 'cap_ny', name: 'NY Cap', type: 'cap', color: '#1a1a1a', price: 1 },
        { id: 'cap_la', name: 'LA Cap', type: 'cap', color: '#000000', price: 1 }
    ],
    
    bandanas: [
        { id: 'bandana_none', name: 'No Bandana', type: 'bandana', color: 'transparent', price: 0 },
        { id: 'bandana_red', name: 'Red Bandana', type: 'bandana', color: '#ff4757', price: 1 },
        { id: 'bandana_blue', name: 'Blue Bandana', type: 'bandana', color: '#1e90ff', price: 1 },
        { id: 'bandana_green', name: 'Green Bandana', type: 'bandana', color: '#2ecc71', price: 1 },
        { id: 'bandana_black', name: 'Black Bandana', type: 'bandana', color: '#000000', price: 1 },
        { id: 'bandana_white', name: 'White Bandana', type: 'bandana', color: '#ffffff', price: 1 },
        { id: 'bandana_purple', name: 'Purple Bandana', type: 'bandana', color: '#9b59b6', price: 1 },
        { id: 'bandana_pink', name: 'Pink Bandana', type: 'bandana', color: '#fd79a8', price: 1 },
        { id: 'bandana_gold', name: 'Gold Bandana', type: 'bandana', color: '#FFD700', price: 1 },
        { id: 'bandana_rainbow', name: 'Rainbow Bandana', type: 'bandana', color: 'linear-gradient(90deg, #ff0000, #ff9900, #ffff00, #00ff00, #00ffff, #0000ff, #9900ff)', price: 1 }
    ],
    
    shoes: [
        { id: 'shoes_default', name: 'Basic Shoes', type: 'shoes', color: '#333333', style: 'normal', price: 0 },
        { id: 'shoes_red', name: 'Red Shoes', type: 'shoes', color: '#ff4757', style: 'normal', price: 1 },
        { id: 'shoes_blue', name: 'Blue Shoes', type: 'shoes', color: '#1e90ff', style: 'normal', price: 1 },
        { id: 'shoes_white', name: 'White Shoes', type: 'shoes', color: '#ffffff', style: 'normal', price: 1 },
        { id: 'shoes_black', name: 'Black Shoes', type: 'shoes', color: '#000000', style: 'normal', price: 1 },
        { id: 'shoes_green', name: 'Green Shoes', type: 'shoes', color: '#00ce6b', style: 'normal', price: 1 },
        { id: 'shoes_gold', name: 'Gold Shoes', type: 'shoes', color: '#FFD700', style: 'normal', price: 1 },
        { id: 'shoes_high_top_red', name: 'High-top (Red)', type: 'shoes', color: '#ff4757', style: 'high', price: 1 },
        { id: 'shoes_high_top_black', name: 'High-top (Black)', type: 'shoes', color: '#000000', style: 'high', price: 1 },
        { id: 'shoes_sneakers_white', name: 'Sneakers (White)', type: 'shoes', color: '#ffffff', style: 'sneakers', price: 1 },
        { id: 'shoes_sneakers_blue', name: 'Sneakers (Blue)', type: 'shoes', color: '#3498db', style: 'sneakers', price: 1 },
        { id: 'shoes_running_red', name: 'Running (Red)', type: 'shoes', color: '#e74c3c', style: 'running', price: 1 },
        { id: 'shoes_running_green', name: 'Running (Green)', type: 'shoes', color: '#2ecc71', style: 'running', price: 1 },
        { id: 'shoes_basket_black', name: 'Basketball (Black)', type: 'shoes', color: '#000000', style: 'basket', price: 1 },
        { id: 'shoes_basket_red', name: 'Basketball (Red)', type: 'shoes', color: '#ff0000', style: 'basket', price: 1 },
        { id: 'shoes_neon_green', name: 'Neon Green', type: 'shoes', color: '#76FF03', style: 'normal', price: 1 }
    ],
    
    accessories: [
        { id: 'watch_none', name: 'No Watch', type: 'watch', color: 'transparent', price: 0 },
        { id: 'watch_silver', name: 'Silver Watch', type: 'watch', color: '#bdc3c7', price: 1 },
        { id: 'watch_gold', name: 'Gold Watch', type: 'watch', color: '#FFD700', price: 1 },
        { id: 'watch_black', name: 'Black Watch', type: 'watch', color: '#2c3e50', price: 1 },
        { id: 'watch_red', name: 'Red Watch', type: 'watch', color: '#ff4757', price: 1 },
        { id: 'watch_digital', name: 'Digital Watch', type: 'watch', color: '#00E5FF', price: 1 },
        
        { id: 'chain_none', name: 'No Chain', type: 'chain', color: 'transparent', price: 0 },
        { id: 'chain_silver', name: 'Silver Chain', type: 'chain', color: '#ecf0f1', price: 1 },
        { id: 'chain_gold', name: 'Gold Chain', type: 'chain', color: '#FFD700', price: 1 },
        { id: 'chain_black', name: 'Black Chain', type: 'chain', color: '#000000', price: 1 },
        { id: 'chain_steel', name: 'Steel Chain', type: 'chain', color: '#95a5a6', price: 1 },
        { id: 'chain_diamond', name: 'Diamond Chain', type: 'chain', color: '#00E5FF', price: 1 }
    ],
    
    stick: [
        { id: 'stick_default', name: 'Wood', color: '#5D4037', width: 4, price: 0 },
        { id: 'stick_red', name: 'Laser Red', color: '#ff4757', width: 3, price: 1 },
        { id: 'stick_blue', name: 'Laser Blue', color: '#1e90ff', width: 3, price: 1 },
        { id: 'stick_gold', name: 'Midas Touch', color: '#FFD700', width: 5, price: 1 },
        { id: 'stick_neon', name: 'Neon Green', color: '#76FF03', width: 3, price: 1 },
        { id: 'stick_dark', name: 'Void', color: 'black', width: 6, price: 1 },
        { id: 'stick_rainbow', name: 'Rainbow Beam', color: 'linear-gradient(45deg, #ff0000, #ff9900, #ffff00, #00ff00, #00ffff, #0000ff, #9900ff)', width: 4, price: 1 },
        { id: 'stick_plasma', name: 'Plasma', color: 'linear-gradient(180deg, #00ffff, #ff00ff)', width: 3, price: 1 },
        { id: 'stick_cosmic', name: 'Cosmic Ray', color: 'linear-gradient(90deg, #3a0ca3, #7209b7, #f72585)', width: 5, price: 1 },
        { id: 'stick_lava', name: 'Lava Flow', color: 'linear-gradient(0deg, #ff5400, #ffbd00)', width: 6, price: 1 },
        { id: 'stick_ice', name: 'Ice Shard', color: 'linear-gradient(180deg, #a2d2ff, #cdb4db)', width: 3, price: 1 },
        { id: 'stick_lightning', name: 'Lightning', color: 'linear-gradient(45deg, #ffff00, #ffffff)', width: 2, price: 1 },
        { id: 'stick_neon_pink', name: 'Neon Pink', color: '#ff006e', width: 3, price: 1 },
        { id: 'stick_galaxy', name: 'Galaxy Rod', color: 'linear-gradient(90deg, #000000, #3c096c, #9d4edd)', width: 5, price: 1 },
        { id: 'stick_diamond', name: 'Diamond', color: 'linear-gradient(45deg, #ffffff, #b9fbc0)', width: 4, price: 1 },
        { id: 'stick_fire', name: 'Fire Blaze', color: 'linear-gradient(0deg, #ff0000, #ff9500)', width: 7, price: 1 },
        { id: 'stick_ocean', name: 'Ocean Wave', color: 'linear-gradient(90deg, #0077b6, #00b4d8)', width: 4, price: 1 },
        { id: 'stick_forest', name: 'Forest Vine', color: 'linear-gradient(0deg, #386641, #a7c957)', width: 5, price: 1 },
        { id: 'stick_sunset', name: 'Sunset', color: 'linear-gradient(45deg, #ff6d00, #ff9e00, #ffbe0b)', width: 4, price: 1 },
        { id: 'stick_cyber', name: 'Cyber Stick', color: 'linear-gradient(90deg, #ff00ff, #00ffff)', width: 3, price: 1 },
        { id: 'stick_royal', name: 'Royal Scepter', color: 'linear-gradient(180deg, #3a0ca3, #4361ee)', width: 6, price: 1 },
        { id: 'stick_phantom', name: 'Phantom Rod', color: 'linear-gradient(45deg, #560bad, #b5179e)', width: 4, price: 1 },
        { id: 'stick_neon_cyan', name: 'Neon Cyan', color: '#00ffff', width: 3, price: 1 },
        { id: 'stick_universe', name: 'Universe', color: 'linear-gradient(90deg, #000000, #14213d, #fca311)', width: 5, price: 1 }
    ],
    
    platform: [
        { id: 'plat_default', name: 'Stone Platform', color: '#424242', cloud: true, floating: true, price: 0 },
        { id: 'plat_ice', name: 'Ice Platform', color: '#81D4FA', cloud: true, floating: true, price: 1 },
        { id: 'plat_mars', name: 'Mars Platform', color: '#BF360C', cloud: true, floating: true, price: 1 },
        { id: 'plat_grass', name: 'Grass Platform', color: '#388E3C', cloud: true, floating: true, price: 1 },
        { id: 'plat_gold', name: 'Gold Platform', color: '#FFC107', cloud: true, floating: true, price: 1 },
        { id: 'plat_cyber', name: 'Cyber Platform', color: '#2c3e50', cloud: true, floating: true, price: 1 },
        { id: 'plat_crystal', name: 'Crystal Platform', color: 'linear-gradient(135deg, #a2d2ff, #cdb4db)', cloud: true, floating: true, price: 1 },
        { id: 'plat_lava', name: 'Lava Platform', color: 'linear-gradient(45deg, #ff5400, #ffbd00)', cloud: true, floating: true, price: 1 },
        { id: 'plat_neon', name: 'Neon Platform', color: 'linear-gradient(90deg, #ff006e, #8338ec)', cloud: true, floating: true, price: 1 },
        { id: 'plat_galaxy', name: 'Galaxy Platform', color: 'linear-gradient(180deg, #240046, #5a189a)', cloud: true, floating: true, price: 1 },
        { id: 'plat_ocean', name: 'Ocean Platform', color: 'linear-gradient(0deg, #0077b6, #00b4d8)', cloud: true, floating: true, price: 1 },
        { id: 'plat_forest', name: 'Forest Platform', color: 'linear-gradient(135deg, #386641, #6a994e)', cloud: true, floating: true, price: 1 },
        { id: 'plat_cloud', name: 'Cloud Platform', color: 'linear-gradient(180deg, #ffffff, #f8f9fa)', cloud: false, floating: true, price: 1 },
        { id: 'plat_diamond', name: 'Diamond Platform', color: 'linear-gradient(45deg, #ffffff, #b9fbc0)', cloud: true, floating: true, price: 1 },
        { id: 'plat_sunset', name: 'Sunset Platform', color: 'linear-gradient(90deg, #ff6d00, #ff9e00)', cloud: true, floating: true, price: 1 },
        { id: 'plat_rainbow', name: 'Rainbow Platform', color: 'linear-gradient(90deg, #ff595e, #ffca3a, #8ac926, #1982c4, #6a4c93)', cloud: true, floating: true, price: 1 },
        { id: 'plat_void', name: 'Void Platform', color: 'linear-gradient(135deg, #000000, #3c096c)', cloud: true, floating: true, price: 1 },
        { id: 'plat_cosmic', name: 'Cosmic Platform', color: 'linear-gradient(45deg, #10002b, #e0aaff)', cloud: true, floating: true, price: 1 },
        { id: 'plat_royal', name: 'Royal Platform', color: 'linear-gradient(180deg, #3a0ca3, #4361ee)', cloud: true, floating: true, price: 1 },
        { id: 'plat_phantom', name: 'Phantom Platform', color: 'linear-gradient(135deg, #560bad, #b5179e)', cloud: true, floating: true, price: 1 },
        { id: 'plat_cyberpunk', name: 'Cyberpunk Platform', color: 'linear-gradient(90deg, #ff00ff, #00ffff)', cloud: true, floating: true, price: 1 },
        { id: 'plat_steel', name: 'Steel Platform', color: 'linear-gradient(135deg, #6c757d, #adb5bd)', cloud: true, floating: true, price: 1 },
        { id: 'plat_golden_brick', name: 'Golden Brick', color: 'linear-gradient(45deg, #ffd700, #ffed4e)', cloud: true, floating: true, price: 1 },
        { id: 'plat_neon_blue', name: 'Neon Blue Platform', color: 'linear-gradient(90deg, #4cc9f0, #4361ee)', cloud: true, floating: true, price: 1 },
        { id: 'plat_universe', name: 'Universe Platform', color: 'linear-gradient(180deg, #000000, #14213d)', cloud: true, floating: true, price: 1 }
    ],
    
    bg: [
        { id: 'bg_default', name: 'Daylight', colors: ['#a8e6cf', '#dcedc1'], hills: '#81c784', price: 0 },
        { id: 'bg_sunset', name: 'Sunset', colors: ['#ff9966', '#ff5e62'], hills: '#a1484b', price: 1 },
        { id: 'bg_midnight', name: 'Midnight', colors: ['#141E30', '#243B55'], hills: '#1c2a38', price: 1 },
        { id: 'bg_forest', name: 'Deep Forest', colors: ['#134E5E', '#71B280'], hills: '#0e3d4a', price: 1 },
        { id: 'bg_candy', name: 'Candy', colors: ['#ff9a9e', '#fecfef'], hills: '#ff6b81', price: 1 },
        { id: 'bg_void', name: 'The Void', colors: ['#000000', '#434343'], hills: '#222', price: 1 },
        { id: 'bg_aurora', name: 'Aurora', colors: ['#00b4d8', '#9d4edd'], hills: '#7209b7', price: 1 },
        { id: 'bg_neon_city', name: 'Neon City', colors: ['#ff006e', '#8338ec'], hills: '#3a86ff', price: 1 },
        { id: 'bg_cyberpunk', name: 'Cyberpunk 2077', colors: ['#ff00ff', '#00ffff'], hills: '#ff5400', price: 1 },
        { id: 'bg_galaxy', name: 'Milky Way', colors: ['#240046', '#5a189a'], hills: '#9d4edd', price: 1 },
        { id: 'bg_lava_world', name: 'Lava World', colors: ['#ff5400', '#ffbd00'], hills: '#ff9500', price: 1 },
        { id: 'bg_ocean_deep', name: 'Ocean Deep', colors: ['#0077b6', '#00b4d8'], hills: '#023e8a', price: 1 },
        { id: 'bg_forest_magic', name: 'Magic Forest', colors: ['#386641', '#a7c957'], hills: '#6a994e', price: 1 },
        { id: 'bg_cosmic', name: 'Cosmic Storm', colors: ['#10002b', '#e0aaff'], hills: '#7b2cbf', price: 1 },
        { id: 'bg_rainbow', name: 'Rainbow Paradise', colors: ['#ff595e', '#ffca3a', '#8ac926', '#1982c4', '#6a4c93'], hills: '#ff006e', price: 1 },
        { id: 'bg_ice_kingdom', name: 'Ice Kingdom', colors: ['#a2d2ff', '#cdb4db'], hills: '#bde0fe', price: 1 },
        { id: 'bg_desert', name: 'Desert Dunes', colors: ['#f4a261', '#e76f51'], hills: '#e9c46a', price: 1 },
        { id: 'bg_sunrise', name: 'Sunrise', colors: ['#ff6d00', '#ff9e00'], hills: '#ffbe0b', price: 1 },
        { id: 'bg_royal', name: 'Royal Palace', colors: ['#3a0ca3', '#4361ee'], hills: '#4cc9f0', price: 1 },
        { id: 'bg_phantom', name: 'Phantom Realm', colors: ['#560bad', '#b5179e'], hills: '#7209b7', price: 1 },
        { id: 'bg_matrix', name: 'The Matrix', colors: ['#00ff41', '#008f11'], hills: '#003b00', price: 1 },
        { id: 'bg_starry_night', name: 'Starry Night', colors: ['#000814', '#001d3d'], hills: '#003566', price: 1 },
        { id: 'bg_fire_kingdom', name: 'Fire Kingdom', colors: ['#dc2f02', '#e85d04'], hills: '#f48c06', price: 1 },
        { id: 'bg_cherry_blossom', name: 'Cherry Blossom', colors: ['#ffafcc', '#ffc8dd'], hills: '#cdb4db', price: 1 },
        { id: 'bg_universe', name: 'Universe', colors: ['#000000', '#14213d'], hills: '#fca311', price: 1 }
    ]
};

// --- GAME VARIABLES ---
Array.prototype.last = function () { return this[this.length - 1]; };
Math.sinus = function (degree) { return Math.sin((degree / 180) * Math.PI); };

let phase = "waiting", lastTimestamp, heroX, heroY, sceneOffset, score = 0;
let platforms = [], sticks = [], coins = [];
let isGameRunning = false;
let currentShopTab = 'hero';
let walkCycle = 0;
let shakeAmount = 0;
let shakeTimer = 0;

const canvas = document.getElementById("game");

// Set canvas size
function resize() {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    draw();
}
window.addEventListener("resize", resize);

const ctx = canvas.getContext("2d");

// Config
const canvasWidth = 375;
const platformHeight = 150;
const heroDistanceFromEdge = 10;
const paddingX = 100;
const perfectAreaSize = 10;
const bgSpeed = 0.2;
// Animation params
const stretchingSpeed = 4;
const turningSpeed = 4;
const walkingSpeed = 4;
const transitioningSpeed = 2;
const fallingSpeed = 2;
const heroWidth = 20;
const heroHeight = 35;
const cloudHeight = 50;

// UI Refs
const introEl = document.getElementById("introduction");
const perfectEl = document.getElementById("perfect");
const doubleCoinEl = document.getElementById("double-coin-msg");
const scoreEl = document.getElementById("score");
const mainMenu = document.getElementById("main-menu");
const shopScreen = document.getElementById("shop-screen");
const gameOverMenu = document.getElementById("game-over-menu");

// --- REVIVE BUTTON LOGIC ---
document.getElementById('btn-revive').onclick = () => {
    if (gameData.coins >= 20) {
        gameData.coins -= 20;
        saveData();
        sounds.revive();
        
        const lastStick = sticks.last();
        sticks = [];
        
        // Пронађи платформу са које је херој пао (последња платформа пре пада)
        let revivePlatformIndex = 0;
        for (let i = platforms.length - 1; i >= 0; i--) {
            // Провери да ли је херој био на овој платформи пре пада
            // Херој је пао са платформе која је била испред њега
            if (platforms[i].x < heroX && platforms[i].x + platforms[i].w > heroX) {
                revivePlatformIndex = i;
                break;
            }
        }
        
        const revivePlatform = platforms[revivePlatformIndex];
        
        // Постави хероја на десни крај платформе са које је пао
        heroX = revivePlatform.x + revivePlatform.w - heroDistanceFromEdge;
        heroY = 0;
        phase = "waiting";
        walkCycle = 0;
        
        // ДОДАЈ ОВАЈ КОД: Постави камеру тачно на хероја
        sceneOffset = Math.max(0, heroX - paddingX);
        
        // Направи нови штап који креће са те платформе
        sticks = [{ 
            x: revivePlatform.x + revivePlatform.w, 
            length: 0, 
            rotation: 0 
        }];
        
        // Очисти све претходне штапове
        if (lastStick) {
            lastStick.rotation = 0;
            lastStick.x = revivePlatform.x + revivePlatform.w;
        }
        
        // Ако постоје неке платформе испред ове, обриши их
        // да не би имао превише платформи на екрану
        const maxPlatformsToKeep = 5;
        if (revivePlatformIndex < platforms.length - maxPlatformsToKeep) {
            platforms = platforms.slice(0, revivePlatformIndex + maxPlatformsToKeep);
        }
        
        // Ако нема довољно платформи испред, генериши нове
        while (platforms.length < revivePlatformIndex + maxPlatformsToKeep + 1) {
            generatePlatform();
        }
        
        // Очисти поени са нових платформи које ће се појавити
        coins = coins.filter(coin => coin.x < revivePlatform.x + revivePlatform.w);
        
        gameOverMenu.style.display = 'none';
        isGameRunning = true;
        lastTimestamp = undefined;
        
        // Нацртај тренутно стање пре него што почне анимација
        draw();
        window.requestAnimationFrame(animate);
    }
};

// --- INITIALIZATION ---
updateUI();
resize();

// Event Listeners
document.getElementById('btn-start').onclick = startGame;
document.getElementById('btn-shop').onclick = openShop;
document.getElementById('btn-restart-go').onclick = () => { gameOverMenu.style.display = 'none'; startGame(); };
document.getElementById('btn-shop-go').onclick = () => { gameOverMenu.style.display = 'none'; openShop(); };
document.getElementById('btn-back').onclick = closeShop;

function updateUI() {
    document.getElementById('coin-count').innerText = gameData.coins;
    document.getElementById('shop-coin-count').innerText = gameData.coins;
    document.getElementById('best-score').innerText = gameData.bestScore;
    document.getElementById('final-score-display').innerText = score;
    document.getElementById('final-best-display').innerText = gameData.bestScore;
}

// --- SHOP LOGIC ---
function openShop() {
    mainMenu.style.display = 'none';
    shopScreen.style.display = 'flex';
    switchTab(currentShopTab);
}

function closeShop() {
    shopScreen.style.display = 'none';
    if(phase === 'falling' || score > 0) gameOverMenu.style.display = 'block';
    else mainMenu.style.display = 'block';
    draw();
}

window.switchTab = (category) => {
    currentShopTab = category;
    document.querySelectorAll('.shop-tabs button').forEach(b => b.classList.remove('tab-active'));
    event.target.classList.add('tab-active');
    renderShopItems(category);
}

function renderShopItems(cat) {
    const container = document.getElementById('shop-items');
    container.innerHTML = '';
    
    if (!shopItems[cat]) return;
    
    shopItems[cat].forEach(item => {
        const owned = gameData.inventory.includes(item.id);
        const equipped = gameData.equipped[cat] === item.id;
        
        const card = document.createElement('div');
        card.className = `shop-item-card ${equipped ? 'equipped' : ''} ${!owned ? 'locked' : ''}`;
        
        // Preview Canvas
        const pCv = document.createElement('canvas');
        pCv.width = 70; pCv.height = 70;
        pCv.className = 'item-preview-canvas';
        drawShopPreview(pCv.getContext('2d'), cat, item);
        
        const info = document.createElement('div');
        info.className = 'item-info';
        info.innerHTML = `
            <span class="item-name">${item.name}</span>
            <span class="item-price">${owned ? (equipped ? 'EQUIPPED' : 'OWNED') : item.price + ' 💎'}</span>
        `;
        
        card.appendChild(pCv);
        card.appendChild(info);
        
        card.onclick = () => {
            if (owned) {
                gameData.equipped[cat] = item.id;
                saveData(); renderShopItems(cat); 
            } else if (gameData.coins >= item.price) {
                gameData.coins -= item.price;
                gameData.inventory.push(item.id);
                gameData.equipped[cat] = item.id;
                saveData(); renderShopItems(cat);
            }
        };
        container.appendChild(card);
    });
}

// --- SHOP PREVIEW DRAWING ---
function drawShopPreview(ctx, type, item) {
    ctx.clearRect(0, 0, 70, 70);
    const cx = 35, cy = 65;

    if (type === 'hero') {
        drawHeroVisual(ctx, cx, cy, item.color, 1.2, false);
    } 
    else if (type === 'hats' || type === 'caps' || type === 'bandanas') {
        const heroItem = getEquippedItem('hero');
        drawHeroVisual(ctx, cx, cy, heroItem.color, 1.2, false);
        drawAccessory(ctx, cx, cy - 8, type, item, 1.2, false);
    }
    else if (type === 'shoes') {
        const heroItem = getEquippedItem('hero');
        drawHeroVisual(ctx, cx, cy, heroItem.color, 1.2, false);
        // Za preview, nacrtaj patike na postojećim nogama
        drawAccessory(ctx, cx, cy - 8, type, item, 1.2, false);
    }
    else if (type === 'accessories') {
        const heroItem = getEquippedItem('hero');
        drawHeroVisual(ctx, cx, cy, heroItem.color, 1.2, false);
        drawAccessory(ctx, cx, cy - 8, type, item, 1.2, false);
    }
    else if (type === 'stick') {
        ctx.strokeStyle = applyStyle(ctx, item.color, cx, 10, 0, 50);
        ctx.lineWidth = item.width || 4;
        ctx.lineCap = 'round';
        ctx.beginPath(); 
        ctx.moveTo(cx, 10); 
        ctx.lineTo(cx, 60); 
        ctx.stroke();
    } 
    else if (type === 'platform') {
        const platTop = 25;
        const platHeight = 30;
        
        ctx.fillStyle = applyStyle(ctx, item.color, 15, platTop, 40, platHeight);
        ctx.fillRect(15, platTop, 40, platHeight);
        
        if (item.cloud !== false) {
            ctx.fillStyle = "rgba(255, 255, 255, 0.8)";
            drawCloudShape(ctx, 35, platTop + platHeight + 10, 30, 15);
        }
        
        ctx.fillStyle = "rgba(0,0,0,0.2)";
        ctx.fillRect(15, platTop, 5, platHeight);
    } 
    else if (type === 'bg') {
        const gr = ctx.createLinearGradient(0, 0, 0, 70);
        item.colors.forEach((c, i) => gr.addColorStop(i/(item.colors.length-1), c));
        ctx.fillStyle = gr; 
        ctx.fillRect(0, 0, 70, 70);
        ctx.fillStyle = item.hills;
        ctx.beginPath(); 
        ctx.moveTo(0, 70); ctx.lineTo(0, 50); 
        ctx.quadraticCurveTo(35, 40, 70, 50); ctx.lineTo(70, 70); 
        ctx.fill();
    }
}

// --- ACCESSORY DRAWING FUNCTIONS ---
function drawAccessory(ctx, x, y, type, item, scale = 1, isWalking = false) {
    ctx.save();
    ctx.translate(x, y);
    ctx.scale(scale, scale);

    const legMove = isWalking ? Math.sin(walkCycle) * 6 : 0;
    const h = 30; // Visina heroja (tela)
    
    if (type === 'hats' && item.id !== 'hat_none') {
        // Šešir
        ctx.fillStyle = applyStyle(ctx, item.color, -12, -48, 24, 10);
        ctx.beginPath();
        ctx.ellipse(0, -43, 12, 5, 0, 0, Math.PI * 2);
        ctx.fill();
        
        ctx.fillStyle = applyStyle(ctx, item.color, -10, -48, 20, 8);
        ctx.beginPath();
        ctx.roundRect(-10, -48, 20, 8, 3);
        ctx.fill();
    }
    else if (type === 'caps' && item.id !== 'cap_none') {
        // Kačket - kao šešir ali drugačiji
        ctx.fillStyle = applyStyle(ctx, item.color, -12, -45, 24, 8);
        ctx.beginPath();
        ctx.ellipse(0, -41, 12, 4, 0, 0, Math.PI * 2);
        ctx.fill();
        
        ctx.fillStyle = applyStyle(ctx, item.color, -10, -45, 20, 6);
        ctx.beginPath();
        ctx.roundRect(-10, -45, 20, 6, 2);
        ctx.fill();
        
        // Vizir
        ctx.fillStyle = item.color;
        if (item.backwards) {
            ctx.beginPath();
            ctx.moveTo(10, -42);
            ctx.lineTo(25, -47);
            ctx.lineTo(25, -40);
            ctx.lineTo(10, -40);
            ctx.fill();
        } else {
            ctx.beginPath();
            ctx.moveTo(-10, -42);
            ctx.lineTo(-25, -47);
            ctx.lineTo(-25, -40);
            ctx.lineTo(-10, -40);
            ctx.fill();
        }
    }
    else if (type === 'bandanas' && item.id !== 'bandana_none') {
        // Bandana - Kao kačket ali tanje
        ctx.fillStyle = applyStyle(ctx, item.color, -10, -45, 20, 3); // Tanje (3px umesto 6px)
        ctx.beginPath();
        ctx.roundRect(-10, -45, 20, 3, 1); // Manji radius
        ctx.fill();
        
        // Završetak
        ctx.beginPath();
        ctx.moveTo(-10, -44);
        ctx.lineTo(-20, -48);
        ctx.lineTo(-18, -42);
        ctx.lineTo(-10, -42);
        ctx.fill();
    }
    else if (type === 'shoes' && item.id !== 'shoes_default') {
        // Patike - DODAJ NA POSTOJEĆE NOGE
        // Leva patika (donji deo)
        ctx.fillStyle = applyStyle(ctx, item.color, -7, 6 + legMove, 4, 4);
        ctx.fillRect(-7, 6 + legMove, 4, 4);
        
        // Desna patika (donji deo)
        ctx.fillStyle = applyStyle(ctx, item.color, 3, 6 - legMove, 4, 4);
        ctx.fillRect(3, 6 - legMove, 4, 4);
        
        // Dodaj detalje na patikama
        if (item.style === 'high' || item.style === 'basket') {
            // High-top ili košarkaške patike
            ctx.fillStyle = "white";
            ctx.fillRect(-7, 6 + legMove, 4, 2);
            ctx.fillRect(3, 6 - legMove, 4, 2);
        }
        
        if (item.style === 'sneakers') {
            // Sneakers detalj
            ctx.strokeStyle = "white";
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.moveTo(-5, 7 + legMove);
            ctx.lineTo(-3, 7 + legMove);
            ctx.stroke();
            
            ctx.beginPath();
            ctx.moveTo(5, 7 - legMove);
            ctx.lineTo(7, 7 - legMove);
            ctx.stroke();
        }
    }
    else if (type === 'accessories') {
        if (item.type === 'watch' && item.id !== 'watch_none') {
            ctx.fillStyle = item.color;
            ctx.beginPath();
            ctx.ellipse(8, -5, 3, 3, 0, 0, Math.PI * 2);
            ctx.fill();
            ctx.strokeStyle = item.color;
            ctx.lineWidth = 1;
            ctx.stroke();
        }
        else if (item.type === 'chain' && item.id !== 'chain_none') {
            ctx.strokeStyle = item.color;
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.moveTo(-8, -20);
            ctx.lineTo(8, -20);
            ctx.stroke();
            
            ctx.fillStyle = item.color;
            ctx.beginPath();
            ctx.ellipse(0, -20, 2, 1, 0, 0, Math.PI * 2);
            ctx.fill();
        }
    }
    
    ctx.restore();
}

// --- CLOUD DRAWING FUNCTION ---
function drawCloudShape(ctx, x, y, width, height) {
    ctx.save();
    
    ctx.beginPath();
    ctx.ellipse(x, y, width/2, height/2, 0, 0, Math.PI * 2);
    
    ctx.ellipse(x - width/3, y - height/4, width/4, height/3, 0, 0, Math.PI * 2);
    ctx.ellipse(x + width/3, y - height/4, width/4, height/3, 0, 0, Math.PI * 2);
    ctx.ellipse(x - width/4, y + height/4, width/5, height/4, 0, 0, Math.PI * 2);
    ctx.ellipse(x + width/4, y + height/4, width/5, height/4, 0, 0, Math.PI * 2);
    
    ctx.fill();
    
    ctx.fillStyle = "rgba(0,0,0,0.1)";
    ctx.beginPath();
    ctx.ellipse(x - width/4, y, width/6, height/3, 0, 0, Math.PI * 2);
    ctx.fill();
    
    ctx.restore();
}

// --- GAME LOGIC ---
function startGame() {
    mainMenu.style.display = 'none';
    isGameRunning = true;
    score = 0;
    scoreEl.innerText = score;
    resetGame();
}

function resetGame() {
    phase = "waiting"; 
    lastTimestamp = undefined; 
    sceneOffset = 0; 
    walkCycle = 0;
    shakeAmount = 0;
    shakeTimer = 0;
    introEl.style.opacity = 1;
    
    platforms = [{ x: 50, w: 50 }]; 
    generatePlatform(); generatePlatform(); generatePlatform(); generatePlatform();
    
    sticks = [{ x: platforms[0].x + platforms[0].w, length: 0, rotation: 0 }];
    heroX = platforms[0].x + platforms[0].w - heroDistanceFromEdge; 
    heroY = 0;
    
    coins = [];
    
    // ДОДАЈ ОВАЈ КОД: Постави камеру тачно на хероја на почетку
    sceneOffset = Math.max(0, heroX - paddingX);
    
    draw();
}

function generatePlatform() {
    const last = platforms.last(); 
    let furthestX = last.x + last.w;
    
    const x = furthestX + 40 + Math.floor(Math.random() * 160);
    const w = 30 + Math.floor(Math.random() * 50);
    platforms.push({ x, w });
    
    if (Math.random() > 0.4) {
        const isDouble = Math.random() > 0.9;
        const color = isDouble ? '#FFD700' : '#00E5FF';
        const val = isDouble ? 2 : 1;
        
        coins.push({ 
            x: furthestX + (x - furthestX)/2, 
            y: canvas.height - platformHeight - cloudHeight - 25, 
            collected: false,
            color: color,
            value: val,
            floatOffset: Math.random() * 10
        });
    }
}

// --- INPUT HANDLING ---
window.addEventListener("keydown", (e) => {
    if (e.key == " " && isGameRunning) { 
        e.preventDefault();
        if (phase == "waiting") { lastTimestamp = undefined; phase = "stretching"; window.requestAnimationFrame(animate); }
    }
});
window.addEventListener("keyup", (e) => {
    if (e.key == " " && isGameRunning && phase == "stretching") phase = "turning";
});

const startInput = (e) => {
    if(e.target.closest('.menu-btn') || e.target.closest('.shop-item-card')) return;
    if (!isGameRunning || phase != "waiting") return;
    e.preventDefault();
    
    lastTimestamp = undefined; 
    introEl.style.opacity = 0;
    phase = "stretching"; 
    window.requestAnimationFrame(animate);
};

const endInput = (e) => {
    if (!isGameRunning) return;
    if (phase == "stretching") {
        phase = "turning";
    }
};

window.addEventListener("mousedown", startInput);
window.addEventListener("mouseup", endInput);
window.addEventListener("touchstart", startInput, { passive: false });
window.addEventListener("touchend", endInput);

// --- MAIN LOOP ---
function animate(timestamp) {
    if (!lastTimestamp) { lastTimestamp = timestamp; window.requestAnimationFrame(animate); return; }
    let delta = timestamp - lastTimestamp;

    if (shakeTimer > 0) {
        shakeTimer -= delta;
        shakeAmount = Math.max(0, shakeTimer / 100);
    } else {
        shakeAmount = 0;
    }

    coins.forEach(c => c.floatOffset += 0.1);

    switch (phase) {
        case "waiting": return;
        case "stretching": 
            sticks.last().length += delta / stretchingSpeed; 
            break;
        case "turning":
            sticks.last().rotation += delta / turningSpeed;
            if (sticks.last().rotation > 90) {
                sticks.last().rotation = 90;
                const [nextPlat, perfect] = checkHit();
                if (nextPlat) {
                    score += perfect ? 2 : 1;
                    scoreEl.innerText = score;
                    if (perfect) { 
                        perfectEl.style.opacity = 1; 
                        setTimeout(() => perfectEl.style.opacity = 0, 800); 
                        sounds.perfect();
                    }
                    generatePlatform();
                } else {
                    sounds.stickFall();
                    shakeTimer = 500;
                }
                phase = "walking";
            }
            break;
        case "walking":
            heroX += delta / walkingSpeed;
            walkCycle += delta * 0.15;
            
            coins.forEach(c => { 
                if(!c.collected && Math.abs(heroX - c.x) < 20) { 
                    c.collected = true; 
                    gameData.coins += c.value;
                    sounds.coin();
                    if(c.value > 1) {
                        doubleCoinEl.style.opacity = 1;
                        setTimeout(() => doubleCoinEl.style.opacity = 0, 800);
                    }
                    saveData();
                } 
            });

            const [nextPlat] = checkHit();
            const stick = sticks.last();
            const maxHeroX = nextPlat ? nextPlat.x + nextPlat.w - heroDistanceFromEdge : stick.x + stick.length + heroWidth + 10;
            
            if (heroX > maxHeroX) {
                heroX = maxHeroX;
                phase = nextPlat ? "transitioning" : "falling";
            }
            break;
        case "transitioning":
            sceneOffset += delta / transitioningSpeed;
            const [next] = checkHit();
            if (sceneOffset > next.x + next.w - paddingX) {
                sticks.push({ x: next.x + next.w, length: 0, rotation: 0 });
                phase = "waiting";
            }
            break;
        case "falling":
    if (sticks.last().rotation < 180) sticks.last().rotation += delta / turningSpeed;
    heroY += delta / fallingSpeed;
    
    // ДОДАЈ ОВАЈ КОД: Прати хероја камером док пада
    if (heroX - sceneOffset > paddingX + 50) {
        sceneOffset += delta / transitioningSpeed * 0.5;
    } else if (heroX - sceneOffset < paddingX - 50) {
        sceneOffset -= delta / transitioningSpeed * 0.5;
    }
    
    if (heroY > platformHeight + 100) {
        isGameRunning = false;
        if(score > gameData.bestScore) {
            gameData.bestScore = score;
            saveData();
        }
        document.getElementById('final-score-display').innerText = score;
        updateUI();
        
        const reviveBtn = document.getElementById('btn-revive');
        reviveBtn.style.display = gameData.coins >= 20 ? 'block' : 'none';
        gameOverMenu.style.display = 'block';
        return;
    }
    break;
    }
    
    draw();
    window.requestAnimationFrame(animate);
    lastTimestamp = timestamp;
}

function checkHit() {
    const s = sticks.last();
    const farX = s.x + s.length;
    const hit = platforms.find(p => p.x < farX && farX < p.x + p.w);
    const perfect = hit && (farX > hit.x + hit.w/2 - perfectAreaSize/2 && farX < hit.x + hit.w/2 + perfectAreaSize/2);
    return [hit, perfect];
}

function getEquippedItem(type) {
    const id = gameData.equipped[type];
    return shopItems[type].find(i => i.id === id) || shopItems[type][0];
}

// --- RENDER ---
function draw() {
    const shakeX = shakeAmount > 0 ? (Math.random() * shakeAmount - shakeAmount/2) : 0;
    const shakeY = shakeAmount > 0 ? (Math.random() * shakeAmount/2 - shakeAmount/4) : 0;
    
    const bgItem = getEquippedItem('bg');
    const gr = ctx.createLinearGradient(0, 0, 0, canvas.height);
    gr.addColorStop(0, bgItem.colors[0]); gr.addColorStop(1, bgItem.colors[1]);
    ctx.fillStyle = gr; 
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    drawHill(bgItem.hills);

    ctx.save();
    ctx.translate((canvas.width - canvasWidth)/2 - sceneOffset + shakeX, shakeY);

    const platItem = getEquippedItem('platform');
    const platformTop = canvas.height - platformHeight - cloudHeight;
    
    platforms.forEach(({ x, w }) => {
        ctx.fillStyle = applyStyle(ctx, platItem.color, x, platformTop, w, platformHeight);
        ctx.fillRect(x, platformTop, w, platformHeight);
        
        ctx.fillStyle = "rgba(0,0,0,0.2)";
        ctx.fillRect(x, platformTop, 5, platformHeight);
        
        if (platItem.cloud !== false) {
            ctx.fillStyle = "rgba(255, 255, 255, 0.8)";
            drawCloudShape(ctx, x + w/2, platformTop + platformHeight, w + 20, cloudHeight);
        }
        
        if (sticks.last().x < x) {
            ctx.fillStyle = "#ff4757";
            const cx = x + w/2;
            const cy = platformTop + 2.5;
            const radius = perfectAreaSize / 2;
            ctx.beginPath();
            ctx.arc(cx, cy, radius, 0, Math.PI * 2);
            ctx.fill();
        }
    });

    const stickItem = getEquippedItem('stick');
    sticks.forEach((s) => {
        ctx.save();
        ctx.translate(s.x, platformTop);
        ctx.rotate((Math.PI/180) * s.rotation);
        
        ctx.strokeStyle = applyStyle(ctx, stickItem.color, 0, 0, 0, -s.length);
        ctx.lineWidth = stickItem.width || 4;
        ctx.lineCap = "round";
        ctx.beginPath();
        ctx.moveTo(0,0);
        ctx.lineTo(0, -s.length);
        ctx.stroke();
        ctx.restore();
    });

    const heroItem = getEquippedItem('hero');
    const hatItem = getEquippedItem('hats');
    const capItem = getEquippedItem('caps');
    const bandanaItem = getEquippedItem('bandanas');
    const shoesItem = getEquippedItem('shoes');
    const watchItem = getEquippedItem('accessories');
    const chainItem = shopItems.accessories.find(i => i.id === gameData.equipped.chain) || {id: 'chain_none'};
    
    const drawX = heroX;
    const drawY = heroY + platformTop;
    
    drawHeroVisual(ctx, drawX, drawY, heroItem.color, 1, phase === "walking");
    
    if (shoesItem.id !== 'shoes_default') {
        drawAccessory(ctx, drawX, drawY - 8, 'shoes', shoesItem, 1, phase === "walking");
    }
    if (hatItem.id !== 'hat_none') {
        drawAccessory(ctx, drawX, drawY - 8, 'hats', hatItem, 1);
    }
    if (capItem.id !== 'cap_none') {
        drawAccessory(ctx, drawX, drawY - 8, 'caps', capItem, 1);
    }
    if (bandanaItem.id !== 'bandana_none') {
        drawAccessory(ctx, drawX, drawY - 8, 'bandanas', bandanaItem, 1);
    }
    if (watchItem.id !== 'watch_none') {
        drawAccessory(ctx, drawX, drawY - 8, 'accessories', watchItem, 1);
    }
    if (chainItem.id !== 'chain_none') {
        drawAccessory(ctx, drawX, drawY - 8, 'accessories', chainItem, 1);
    }

    coins.forEach(c => {
        if(c.collected) return;
        const floatY = c.y + Math.sin(c.floatOffset) * 5;
        
        ctx.beginPath();
        ctx.fillStyle = c.color;
        ctx.strokeStyle = "white";
        ctx.lineWidth = 2;
        ctx.moveTo(c.x, floatY - 12);
        ctx.lineTo(c.x + 10, floatY);
        ctx.lineTo(c.x, floatY + 12);
        ctx.lineTo(c.x - 10, floatY);
        ctx.closePath();
        ctx.fill(); ctx.stroke();
        
        ctx.fillStyle = "rgba(255,255,255,0.4)";
        ctx.beginPath();
        ctx.moveTo(c.x, floatY - 12);
        ctx.lineTo(c.x + 5, floatY - 5);
        ctx.lineTo(c.x, floatY);
        ctx.fill();
    });

    ctx.restore();
}

// --- DRAWING FUNCTIONS ---
function drawHeroVisual(ctx, x, y, color, scale = 1, isWalking = false) {
    ctx.save();
    ctx.translate(x, y - 8);
    ctx.scale(scale, scale);

    const legMove = isWalking ? Math.sin(walkCycle) * 6 : 0;
    
    // UVIJEK crtaj noge
    ctx.strokeStyle = "#333";
    ctx.lineWidth = 4;
    ctx.lineCap = 'round';
    
    ctx.beginPath();
    ctx.moveTo(-5, 0); ctx.lineTo(-5, 8 + legMove);
    ctx.moveTo(5, 0); ctx.lineTo(5, 8 - legMove);
    ctx.stroke();

    const w = 20, h = 30;
    ctx.fillStyle = applyStyle(ctx, color, -w/2, -h, w, h);
    ctx.beginPath(); 
    ctx.roundRect(-w/2, -h, w, h, 5); 
    ctx.fill();

    ctx.fillStyle = applyStyle(ctx, color, -8, -h - 16, 16, 16);
    ctx.beginPath(); 
    ctx.arc(0, -h - 8, 8, 0, Math.PI*2); 
    ctx.fill();

    ctx.fillStyle = "white";
    ctx.beginPath(); ctx.arc(4, -h - 8, 3, 0, Math.PI*2); ctx.fill();
    ctx.fillStyle = "black";
    ctx.beginPath(); ctx.arc(5, -h - 8, 1, 0, Math.PI*2); ctx.fill();

    ctx.restore();
}

function drawHill(color) {
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.moveTo(0, canvas.height);
    ctx.lineTo(0, canvas.height - 150);
    const offset = sceneOffset * 0.2;
    for(let i=0; i<=canvas.width; i+=10) {
        ctx.lineTo(i, canvas.height - 150 + Math.sin((i + offset) * 0.01) * 20);
    }
    ctx.lineTo(canvas.width, canvas.height);
    ctx.fill();
}

function applyStyle(ctx, style, x, y, w, h) {
    if (typeof style === 'string' && style.startsWith('linear-gradient')) {
        const colorMatches = style.match(/#(?:[0-9a-fA-F]{3}){1,2}\b|[a-zA-Z]+/g);
        const colors = colorMatches.filter(c => 
            !['linear', 'gradient', 'deg', 'to', 'right', 'bottom', 'left', 'top'].includes(c.toLowerCase())
        );

        const grad = ctx.createLinearGradient(x, y, x + w, y + h);
        colors.forEach((col, index) => {
            grad.addColorStop(index / (colors.length - 1), col);
        });
        return grad;
    }
    return style;
}

if (!CanvasRenderingContext2D.prototype.roundRect) {
    CanvasRenderingContext2D.prototype.roundRect = function(x, y, w, h, r) {
        if (w < 2 * r) r = w / 2;
        if (h < 2 * r) r = h / 2;
        this.beginPath();
        this.moveTo(x + r, y);
        this.arcTo(x + w, y, x + w, y + h, r);
        this.arcTo(x + w, y + h, x, y + h, r);
        this.arcTo(x, y + h, x, y, r);
        this.arcTo(x, y, x + w, y, r);
        this.closePath();
        return this;
    }
}